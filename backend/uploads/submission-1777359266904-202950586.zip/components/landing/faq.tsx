"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const items = [
  {
    q: "Is RIMP free for students?",
    a: "Yes. Students can sign up, enroll in any program, complete tasks, and earn certificates at no cost.",
  },
  {
    q: "How does AI evaluation work?",
    a: "Submissions are sent to Groq's hosted Llama models with the task description and rubric. The AI returns a score, verdict, strengths, improvements, and natural-language feedback in seconds.",
  },
  {
    q: "Can I create my own programs?",
    a: "Sign up as an organization (admin role) to create programs, design tasks with rubrics, and review your cohort.",
  },
  {
    q: "Are certificates verifiable?",
    a: "Every certificate is issued with a unique credential ID, the student name, the program, and a final score derived from passing submissions.",
  },
  {
    q: "What's the tech stack?",
    a: "Next.js + React on the frontend, Node.js API routes on the backend, MongoDB for storage, JWT for sessions, and Groq for AI evaluation.",
  },
]

export function Faq() {
  return (
    <section id="faq" className="relative py-24 md:py-32 bg-muted/30">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-wider">
            FAQ
          </div>
          <h2 className="mt-4 font-display text-balance text-4xl md:text-5xl font-bold tracking-tight">
            Common questions
          </h2>
        </div>
        <Accordion type="single" collapsible className="space-y-3">
          {items.map((it, i) => (
            <AccordionItem
              key={i}
              value={`item-${i}`}
              className="rounded-xl border border-border bg-card px-5 data-[state=open]:border-primary/30"
            >
              <AccordionTrigger className="text-left font-display font-semibold text-base hover:no-underline py-5">
                {it.q}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">{it.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}
