"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight, GraduationCap } from "lucide-react"

export function CtaFooter() {
  return (
    <>
      <section className="relative py-24 md:py-32">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative overflow-hidden rounded-3xl border border-border bg-card p-10 md:p-16 text-center"
          >
            <div className="absolute inset-0 grid-bg opacity-40 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_70%)]" />
            <div className="absolute -top-20 left-1/2 -translate-x-1/2 h-60 w-[600px] rounded-full bg-primary/30 blur-[100px]" />

            <div className="relative">
              <h2 className="font-display text-balance text-4xl md:text-5xl font-bold tracking-tight">
                Build the team of tomorrow.
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground text-pretty">
                Join hundreds of organizations and thousands of students using RIMP to grow real, verifiable skills.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
                <Button asChild size="lg" className="h-12 px-6 text-base shadow-xl shadow-primary/25 group">
                  <Link href="/signup">
                    Create free account
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="ghost" className="h-12 px-6 text-base">
                  <Link href="/login">I already have an account</Link>
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <footer className="border-t border-border py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <GraduationCap className="h-4 w-4" />
              </div>
              <span className="font-display font-bold">RIMP</span>
              <span className="text-sm text-muted-foreground">— Remote Internship Management Platform</span>
            </Link>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <Link href="/login" className="hover:text-foreground transition-colors">
                Sign in
              </Link>
              <Link href="/signup" className="hover:text-foreground transition-colors">
                Get started
              </Link>
              <span>© {new Date().getFullYear()} RIMP</span>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}
