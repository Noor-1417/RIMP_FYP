"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, CheckCircle2 } from "lucide-react"

export function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
      {/* Background grid */}
      <div className="absolute inset-0 grid-bg [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_70%)]" />
      {/* Glows */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 h-[400px] w-[800px] rounded-full bg-primary/20 blur-[120px] -z-10" />
      <div className="absolute top-40 right-10 h-[300px] w-[300px] rounded-full bg-accent/20 blur-[100px] -z-10" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 backdrop-blur px-4 py-1.5 text-sm font-medium shadow-sm"
          >
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-muted-foreground">AI-powered task evaluation</span>
            <span className="h-1 w-1 rounded-full bg-border" />
            <span className="text-foreground">Powered by Groq</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="mt-8 font-display text-balance text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.05]"
          >
            Remote internships,{" "}
            <span className="relative inline-block">
              <span className="relative z-10 bg-gradient-to-br from-primary via-primary to-accent bg-clip-text text-transparent">
                reimagined.
              </span>
              <motion.span
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="absolute bottom-1 left-0 right-0 h-3 bg-accent/30 -z-0 origin-left"
              />
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed"
          >
            Host structured remote internship programs, assign real-world tasks, and let AI deliver instant,
            actionable feedback. Students earn verified certificates as they grow.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3"
          >
            <Button asChild size="lg" className="h-12 px-6 text-base shadow-xl shadow-primary/25 group">
              <Link href="/signup">
                Start as a student
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-12 px-6 text-base bg-card/50 backdrop-blur">
              <Link href="/signup?role=admin">For organizations</Link>
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground"
          >
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              No credit card required
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              Free for students
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              Verifiable certificates
            </span>
          </motion.div>
        </div>

        {/* Hero visual: stacked cards */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.4 }}
          className="relative mx-auto mt-20 max-w-5xl"
        >
          <HeroVisual />
        </motion.div>
      </div>
    </section>
  )
}

function HeroVisual() {
  return (
    <div className="relative">
      {/* Glow under the card */}
      <div className="absolute -inset-x-20 -bottom-10 h-40 bg-primary/30 blur-3xl rounded-full" />

      <div className="relative rounded-2xl border border-border bg-card shadow-2xl shadow-primary/10 overflow-hidden">
        {/* Window chrome */}
        <div className="flex items-center justify-between border-b border-border bg-muted/30 px-4 py-3">
          <div className="flex gap-1.5">
            <div className="h-3 w-3 rounded-full bg-destructive/70" />
            <div className="h-3 w-3 rounded-full bg-amber-400" />
            <div className="h-3 w-3 rounded-full bg-accent" />
          </div>
          <div className="text-xs font-mono text-muted-foreground">rimp.io/dashboard</div>
          <div className="w-12" />
        </div>

        <div className="grid lg:grid-cols-[260px_1fr] min-h-[420px]">
          {/* Sidebar */}
          <div className="hidden lg:flex flex-col gap-1 border-r border-border bg-muted/20 p-4">
            <div className="px-3 py-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Workspace
            </div>
            {[
              { label: "Dashboard", active: true },
              { label: "Programs", active: false },
              { label: "Tasks", active: false },
              { label: "Certificates", active: false },
            ].map((it) => (
              <div
                key={it.label}
                className={`px-3 py-2 rounded-lg text-sm font-medium ${
                  it.active ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {it.label}
              </div>
            ))}
          </div>

          {/* Main */}
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="text-xs text-muted-foreground">Welcome back</div>
                <div className="font-display font-bold text-xl">Your active programs</div>
              </div>
              <div className="hidden sm:flex h-9 px-3 items-center rounded-lg bg-primary text-primary-foreground text-sm font-medium">
                + Enroll
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              {[
                { title: "Frontend with React", progress: 75, color: "bg-primary" },
                { title: "Data Analytics", progress: 40, color: "bg-accent" },
                { title: "Product Design", progress: 100, color: "bg-amber-500" },
                { title: "ML Foundations", progress: 15, color: "bg-rose-500" },
              ].map((p, i) => (
                <motion.div
                  key={p.title}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + i * 0.1 }}
                  className="rounded-xl border border-border bg-background p-4"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-sm font-semibold">{p.title}</div>
                    <div className="text-xs font-mono text-muted-foreground">{p.progress}%</div>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${p.progress}%` }}
                      transition={{ duration: 1.2, delay: 0.9 + i * 0.1, ease: "easeOut" }}
                      className={`h-full ${p.color}`}
                    />
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-4 rounded-xl border border-border bg-gradient-to-br from-primary/5 to-accent/5 p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/15">
                  <Sparkles className="h-4 w-4 text-accent" />
                </div>
                <div>
                  <div className="text-sm font-semibold">AI feedback ready</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {'"Strong semantic HTML and clean state handling. Score: 88 / 100."'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating badge */}
      <motion.div
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY }}
        className="hidden md:flex absolute -left-6 top-20 items-center gap-2 rounded-full border border-border bg-card px-4 py-2 shadow-xl"
      >
        <CheckCircle2 className="h-4 w-4 text-accent" />
        <span className="text-sm font-medium">Certificate issued</span>
      </motion.div>

      <motion.div
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY }}
        className="hidden md:flex absolute -right-4 bottom-20 items-center gap-2 rounded-full border border-border bg-card px-4 py-2 shadow-xl"
      >
        <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
        <span className="text-sm font-medium">3 tasks pending review</span>
      </motion.div>
    </div>
  )
}
