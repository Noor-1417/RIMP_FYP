"use client"

import { motion } from "framer-motion"
import {
  Sparkles,
  ClipboardList,
  Award,
  Users,
  LineChart,
  Shield,
} from "lucide-react"

const features = [
  {
    icon: Sparkles,
    title: "AI-graded submissions",
    desc: "Groq-powered evaluation gives students instant, rubric-based feedback with strengths and improvements.",
  },
  {
    icon: ClipboardList,
    title: "Structured programs",
    desc: "Build multi-week internships with sequenced tasks, rubrics, and clear learning outcomes.",
  },
  {
    icon: Award,
    title: "Verified certificates",
    desc: "Auto-issue tamper-resistant certificates with unique credential IDs once a student completes a program.",
  },
  {
    icon: Users,
    title: "Cohort dashboard",
    desc: "Admins see every learner, their progress, and submission scores in a single, focused view.",
  },
  {
    icon: LineChart,
    title: "Progress that motivates",
    desc: "Live progress bars, completion streaks, and skill badges keep students moving forward.",
  },
  {
    icon: Shield,
    title: "Secure by default",
    desc: "Hashed passwords, JWT sessions, and role-based access. Your data stays in your MongoDB.",
  },
]

export function Features() {
  return (
    <section id="features" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            Platform
          </div>
          <h2 className="mt-4 font-display text-balance text-4xl md:text-5xl font-bold tracking-tight">
            Everything you need to run a great internship
          </h2>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            From program creation to AI-reviewed submissions and verified certificates — all in one place.
          </p>
        </div>

        <div className="mt-16 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="group relative rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-5 font-display font-semibold text-lg">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
