"use client"

import { motion } from "framer-motion"
import { Code2, BarChart3, Palette, Brain, Server, Megaphone } from "lucide-react"

const programs = [
  { icon: Code2, title: "Frontend Engineering", tag: "React · TS · Tailwind", weeks: 4 },
  { icon: BarChart3, title: "Data Analytics", tag: "SQL · Pandas · Viz", weeks: 6 },
  { icon: Palette, title: "Product Design", tag: "Figma · Research · UX", weeks: 3 },
  { icon: Brain, title: "ML Foundations", tag: "Python · Scikit · DL", weeks: 8 },
  { icon: Server, title: "Backend Engineering", tag: "Node · APIs · DB", weeks: 5 },
  { icon: Megaphone, title: "Growth Marketing", tag: "SEO · Ads · CRM", weeks: 4 },
]

export function ProgramsPreview() {
  return (
    <section id="programs" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div className="max-w-xl">
            <div className="inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
              Programs
            </div>
            <h2 className="mt-4 font-display text-balance text-4xl md:text-5xl font-bold tracking-tight">
              Real skills, real projects
            </h2>
          </div>
          <p className="md:max-w-md text-muted-foreground text-pretty">
            Curated by working professionals. Every task is reviewed by AI against a clear rubric so feedback is fast,
            specific, and consistent.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {programs.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 hover:border-primary/30 transition-all"
            >
              <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-primary/5 transition-all group-hover:bg-primary/10" />
              <div className="relative flex items-start justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <p.icon className="h-5 w-5" />
                </div>
                <span className="text-xs font-mono text-muted-foreground">{p.weeks} weeks</span>
              </div>
              <h3 className="relative mt-5 font-display font-semibold text-lg">{p.title}</h3>
              <p className="relative mt-1 text-sm text-muted-foreground">{p.tag}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
