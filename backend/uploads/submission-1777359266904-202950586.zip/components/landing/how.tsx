"use client"

import { motion } from "framer-motion"

const steps = [
  {
    n: "01",
    title: "Choose a program",
    desc: "Browse internship programs across engineering, data, design, and more. Enroll in one click.",
  },
  {
    n: "02",
    title: "Complete real tasks",
    desc: "Work through curated, real-world tasks. Submit text writeups and links to your work.",
  },
  {
    n: "03",
    title: "Get AI feedback",
    desc: "Groq instantly evaluates your submission against the rubric, scoring strengths and improvements.",
  },
  {
    n: "04",
    title: "Earn your certificate",
    desc: "Pass every task and an auto-verified certificate is issued with a unique credential ID.",
  },
]

export function How() {
  return (
    <section id="how" className="relative py-24 md:py-32 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent-foreground">
            How it works
          </div>
          <h2 className="mt-4 font-display text-balance text-4xl md:text-5xl font-bold tracking-tight">
            From sign-up to certified, in four steps
          </h2>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative rounded-2xl border border-border bg-card p-6"
            >
              <div className="flex items-center gap-3 mb-4">
                <span className="font-mono text-sm font-bold text-primary">{s.n}</span>
                <div className="h-px flex-1 bg-border" />
              </div>
              <h3 className="font-display font-bold text-xl">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
