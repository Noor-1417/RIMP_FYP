"use client"

import { useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

/**
 * Forces students to complete their application before using any other dashboard route.
 * Mounted globally inside AppShell.
 */
export function OnboardingGuard() {
  const router = useRouter()
  const pathname = usePathname()
  const { data } = useSWR("/api/auth/me", fetcher, { revalidateOnFocus: false })

  useEffect(() => {
    if (!data?.user) return
    if (data.user.role !== "student") return
    if (data.user.hasApplication) return
    if (pathname?.startsWith("/dashboard/onboarding")) return
    router.replace("/dashboard/onboarding")
  }, [data, pathname, router])

  return null
}
