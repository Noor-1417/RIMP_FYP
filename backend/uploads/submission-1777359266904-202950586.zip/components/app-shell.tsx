"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useState } from "react"
import {
  GraduationCap,
  LayoutDashboard,
  BookOpen,
  ClipboardCheck,
  Award,
  LogOut,
  Menu,
  X,
  Users,
  Settings,
  Plus,
  Bot,
  UserCircle,
  ShieldAlert,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { OnboardingGuard } from "@/components/onboarding-guard"

type NavItem = { href: string; label: string; icon: typeof LayoutDashboard }

export type SessionUser = { id: string; name: string; email: string; role: "student" | "admin" }

const studentNav: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/dashboard/programs", label: "Programs", icon: BookOpen },
  { href: "/dashboard/tasks", label: "Tasks", icon: ClipboardCheck },
  { href: "/dashboard/chat", label: "AI Mentor", icon: Bot },
  { href: "/dashboard/certificates", label: "Certificates", icon: Award },
  { href: "/dashboard/profile", label: "Profile", icon: UserCircle },
]

const adminNav: NavItem[] = [
  { href: "/admin", label: "Overview", icon: LayoutDashboard },
  { href: "/admin/programs", label: "Programs", icon: BookOpen },
  { href: "/admin/tasks", label: "Tasks", icon: ClipboardCheck },
  { href: "/admin/submissions", label: "AI Reports", icon: ShieldAlert },
  { href: "/admin/students", label: "Students", icon: Users },
]

export function AppShell({
  user,
  children,
}: {
  user: SessionUser
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const nav = user.role === "admin" ? adminNav : studentNav

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" })
    toast.success("Signed out")
    router.push("/")
    router.refresh()
  }

  const initials = user.name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase()

  return (
    <div className="min-h-screen bg-muted/30">
      {user.role === "student" && <OnboardingGuard />}
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border">
        <div className="flex h-16 items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              aria-label="Toggle sidebar"
              onClick={() => setOpen((o) => !o)}
              className="lg:hidden inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <GraduationCap className="h-4 w-4" />
              </div>
              <span className="font-display font-bold">RIMP</span>
              <span
                className={cn(
                  "ml-2 hidden sm:inline-flex text-xs font-semibold px-2 py-0.5 rounded-full",
                  user.role === "admin" ? "bg-accent/15 text-accent-foreground" : "bg-primary/10 text-primary",
                )}
              >
                {user.role === "admin" ? "Admin" : "Student"}
              </span>
            </Link>
          </div>

          <div className="flex items-center gap-2">
            {user.role === "admin" && (
              <Button asChild size="sm" className="hidden sm:inline-flex">
                <Link href="/admin/programs?new=1">
                  <Plus className="h-4 w-4" /> New program
                </Link>
              </Button>
            )}
            {user.role === "student" && (
              <Button asChild size="sm" variant="outline" className="hidden sm:inline-flex bg-transparent">
                <Link href="/dashboard/chat">
                  <Bot className="h-4 w-4" /> Ask mentor
                </Link>
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-full pr-3 pl-1 py-1 hover:bg-muted">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent text-primary-foreground text-xs font-bold">
                    {initials}
                  </div>
                  <span className="hidden sm:block text-sm font-medium">{user.name}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="font-semibold">{user.name}</div>
                  <div className="text-xs font-normal text-muted-foreground">{user.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {user.role === "student" && (
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/profile">
                      <UserCircle className="h-4 w-4" /> Profile
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem disabled>
                  <Settings className="h-4 w-4" /> Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={logout}>
                  <LogOut className="h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={cn(
            "fixed lg:sticky top-16 z-30 h-[calc(100vh-4rem)] w-64 shrink-0 border-r border-border bg-background transition-transform lg:translate-x-0",
            open ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <nav className="flex flex-col gap-1 p-3">
            {nav.map((item) => {
              const active =
                pathname === item.href ||
                (item.href !== "/dashboard" && item.href !== "/admin" && pathname.startsWith(item.href))
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              )
            })}
          </nav>

          {user.role === "student" && (
            <div className="mx-3 mt-4 rounded-xl border border-border bg-gradient-to-br from-primary/5 to-accent/5 p-4">
              <div className="text-sm font-display font-semibold">Stuck on a task?</div>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                Chat with your AI Mentor for hints and concept guidance.
              </p>
              <Button asChild size="sm" variant="outline" className="mt-3 w-full bg-transparent">
                <Link href="/dashboard/chat">
                  <Bot className="h-3.5 w-3.5" /> Open mentor
                </Link>
              </Button>
            </div>
          )}
        </aside>

        {/* Backdrop on mobile */}
        {open && (
          <button
            aria-label="Close sidebar"
            onClick={() => setOpen(false)}
            className="fixed inset-0 top-16 z-20 bg-background/60 backdrop-blur-sm lg:hidden"
          />
        )}

        {/* Main */}
        <motion.main
          key={pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="flex-1 min-w-0 p-4 sm:p-6 lg:p-10"
        >
          {children}
        </motion.main>
      </div>
    </div>
  )
}
