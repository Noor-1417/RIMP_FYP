import Stripe from "stripe"

const key = process.env.STRIPE_SECRET_KEY

let client: Stripe | null = null
export function getStripe(): Stripe {
  if (!key) {
    throw new Error("STRIPE_SECRET_KEY is not configured. Add the Stripe integration to enable paid programs.")
  }
  if (!client) {
    client = new Stripe(key, { apiVersion: "2024-12-18.acacia" as any })
  }
  return client
}

export function isStripeConfigured() {
  return Boolean(key)
}

/**
 * Pricing rule:
 *  - 2 weeks: free
 *  - 4 weeks: $49
 *  - 8 weeks: $99
 *  - 12+ weeks: $149
 */
export function priceForDurationWeeks(weeks: number): number {
  if (weeks <= 2) return 0
  if (weeks <= 4) return 4900
  if (weeks <= 8) return 9900
  return 14900
}
