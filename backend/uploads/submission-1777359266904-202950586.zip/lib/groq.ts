import Groq from "groq-sdk"

const apiKey = process.env.GROQ_API_KEY

let client: Groq | null = null
function getClient() {
  if (!apiKey) {
    throw new Error("GROQ_API_KEY is not configured.")
  }
  if (!client) {
    client = new Groq({ apiKey })
  }
  return client
}

export type EvaluationResult = {
  score: number // 0-100
  verdict: "passed" | "needs_revision" | "failed"
  strengths: string[]
  improvements: string[]
  feedback: string
  plagiarismRisk: number // 0-100, higher = more suspicious
  plagiarismNotes: string
}

export async function evaluateSubmission(input: {
  taskTitle: string
  taskDescription: string
  rubric?: string
  submissionText: string
  fileSummary?: string
  studentName?: string
}): Promise<EvaluationResult> {
  const groq = getClient()

  const system = `You are a strict but encouraging mentor reviewing a student's internship task submission.
You also screen for likely plagiarism (copy-paste from common sources, AI-generated boilerplate, lack of personal voice, generic answers that don't address the task).

Return ONLY valid JSON matching this TypeScript type, no markdown, no preamble:
{
  "score": number (0-100, integer),
  "verdict": "passed" | "needs_revision" | "failed",
  "strengths": string[] (2-4 items),
  "improvements": string[] (2-4 items),
  "feedback": string (2-3 sentences, friendly tone),
  "plagiarismRisk": number (0-100, integer; 0=clearly original, 100=clearly copied),
  "plagiarismNotes": string (1-2 sentences explaining the plagiarism judgment)
}
Pass threshold: score >= 70 -> "passed". 50-69 -> "needs_revision". <50 -> "failed".
If plagiarismRisk >= 70, downgrade verdict to "needs_revision" or "failed".`

  const user = `TASK TITLE: ${input.taskTitle}

TASK DESCRIPTION:
${input.taskDescription}

${input.rubric ? `RUBRIC:\n${input.rubric}\n\n` : ""}STUDENT: ${input.studentName || "anonymous"}

STUDENT WRITEUP:
${input.submissionText}
${input.fileSummary ? `\nATTACHED FILE SUMMARY:\n${input.fileSummary}` : ""}`

  const completion = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    temperature: 0.3,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
  })

  const raw = completion.choices[0]?.message?.content || "{}"
  try {
    const parsed = JSON.parse(raw) as EvaluationResult
    return {
      score: Math.max(0, Math.min(100, Math.round(parsed.score || 0))),
      verdict: parsed.verdict || "needs_revision",
      strengths: parsed.strengths || [],
      improvements: parsed.improvements || [],
      feedback: parsed.feedback || "",
      plagiarismRisk: Math.max(0, Math.min(100, Math.round(parsed.plagiarismRisk ?? 10))),
      plagiarismNotes: parsed.plagiarismNotes || "",
    }
  } catch {
    return {
      score: 0,
      verdict: "needs_revision",
      strengths: [],
      improvements: ["The AI evaluator could not parse the submission. Please try again."],
      feedback: "Evaluation parsing failed. Please resubmit.",
      plagiarismRisk: 0,
      plagiarismNotes: "Could not analyze.",
    }
  }
}

export type GeneratedTask = {
  title: string
  description: string
  rubric: string
  order: number
  points: number
  estimatedDays: number
}

export async function generateTasksForProgram(input: {
  programTitle: string
  programSummary: string
  skills: string[]
  level: string
  durationWeeks: number
  count?: number
}): Promise<GeneratedTask[]> {
  const groq = getClient()
  const count = input.count || Math.max(3, Math.min(6, input.durationWeeks))

  const system = `You design hands-on internship tasks. Return ONLY valid JSON:
{ "tasks": [ { "title": string, "description": string (3-5 sentences, concrete deliverables), "rubric": string (what to grade on), "order": number, "points": number (always 100), "estimatedDays": number (how many days a student should take) } ] }
Tasks must be progressive (easier first), realistic for remote work, and graded by an AI reviewer.`

  const user = `Program: ${input.programTitle}
Level: ${input.level}
Skills: ${input.skills.join(", ")}
Duration: ${input.durationWeeks} weeks
Summary: ${input.programSummary}

Generate exactly ${count} tasks.`

  const completion = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    temperature: 0.6,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
  })

  const raw = completion.choices[0]?.message?.content || "{}"
  try {
    const parsed = JSON.parse(raw)
    const list: GeneratedTask[] = Array.isArray(parsed.tasks) ? parsed.tasks : []
    return list.map((t, i) => ({
      title: t.title || `Task ${i + 1}`,
      description: t.description || "",
      rubric: t.rubric || "Code quality, correctness, clarity.",
      order: t.order || i + 1,
      points: 100,
      estimatedDays: Math.max(1, Math.min(14, Math.round(t.estimatedDays || 5))),
    }))
  } catch {
    return []
  }
}

export type ChatMessage = { role: "user" | "assistant" | "system"; content: string }

export async function chatWithMentor(input: {
  history: ChatMessage[]
  context?: { programTitle?: string; taskTitle?: string }
}): Promise<string> {
  const groq = getClient()
  const sys = `You are RIMP Mentor, a friendly senior engineer guiding remote interns.
Be concise (1-3 short paragraphs). Use bullets when listing steps. Encourage independent thinking - never write the full solution; instead, suggest approaches, give hints, ask probing questions, and point to concepts to study.
${input.context?.programTitle ? `\nProgram: ${input.context.programTitle}` : ""}
${input.context?.taskTitle ? `\nCurrent task: ${input.context.taskTitle}` : ""}`

  const completion = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    temperature: 0.5,
    messages: [{ role: "system", content: sys }, ...input.history],
  })
  return completion.choices[0]?.message?.content || "Sorry, I couldn't respond just now."
}
