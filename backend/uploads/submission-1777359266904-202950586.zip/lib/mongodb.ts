import { MongoClient, type Db } from "mongodb"

const uri = process.env.MONGODB_URI
const dbName = process.env.MONGODB_DB || "rimp"

if (!uri) {
  console.warn("[v0] MONGODB_URI is not set. Database operations will fail until the env var is configured.")
}

let client: MongoClient | undefined
let clientPromise: Promise<MongoClient> | undefined

declare global {
  // eslint-disable-next-line no-var
  var _mongoClientPromise: Promise<MongoClient> | undefined
}

function getClientPromise(): Promise<MongoClient> {
  if (!uri) {
    throw new Error("MONGODB_URI environment variable is not configured.")
  }
  if (process.env.NODE_ENV === "development") {
    if (!global._mongoClientPromise) {
      client = new MongoClient(uri)
      global._mongoClientPromise = client.connect()
    }
    return global._mongoClientPromise
  }
  if (!clientPromise) {
    client = new MongoClient(uri)
    clientPromise = client.connect()
  }
  return clientPromise
}

export async function getDb(): Promise<Db> {
  const c = await getClientPromise()
  return c.db(dbName)
}

export async function getCollections() {
  const db = await getDb()
  return {
    users: db.collection("users"),
    programs: db.collection("programs"),
    enrollments: db.collection("enrollments"),
    tasks: db.collection("tasks"),
    submissions: db.collection("submissions"),
    certificates: db.collection("certificates"),
    applications: db.collection("applications"),
    payments: db.collection("payments"),
    chats: db.collection("chats"),
  }
}
