import { getCollections } from "./mongodb"
import bcrypt from "bcryptjs"
import { ObjectId } from "mongodb"

let seeded = false

/**
 * Idempotent seed of demo data. Runs once per server lifetime.
 * Creates:
 *  - admin@rimp.io / admin123  (admin)
 *  - demo@rimp.io  / demo123   (student)
 *  - 3 sample programs with tasks
 */
export async function ensureSeed() {
  if (seeded) return
  try {
    const { users, programs, tasks } = await getCollections()

    const userCount = await users.countDocuments()
    if (userCount === 0) {
      const adminHash = await bcrypt.hash("admin123", 10)
      const studentHash = await bcrypt.hash("demo123", 10)
      await users.insertMany([
        {
          _id: new ObjectId(),
          email: "admin@rimp.io",
          name: "Riley Admin",
          passwordHash: adminHash,
          role: "admin",
          createdAt: new Date(),
        },
        {
          _id: new ObjectId(),
          email: "demo@rimp.io",
          name: "Demo Student",
          passwordHash: studentHash,
          role: "student",
          createdAt: new Date(),
        },
      ])
    }

    const programCount = await programs.countDocuments()
    if (programCount === 0) {
      const seedPrograms = [
        {
          title: "Frontend Engineering with React",
          slug: "frontend-react",
          summary: "Build modern, accessible web apps using React, TypeScript and Tailwind CSS.",
          duration: "4 weeks",
          level: "Beginner",
          category: "Engineering",
          skills: ["React", "TypeScript", "Tailwind", "Accessibility"],
          color: "indigo",
          createdAt: new Date(),
        },
        {
          title: "Data Analytics Foundations",
          slug: "data-analytics",
          summary: "Learn SQL, data cleaning, and storytelling with real datasets.",
          duration: "6 weeks",
          level: "Intermediate",
          category: "Data",
          skills: ["SQL", "Python", "Pandas", "Visualization"],
          color: "emerald",
          createdAt: new Date(),
        },
        {
          title: "Product Design Sprint",
          slug: "product-design",
          summary: "Run end-to-end design sprints from research to interactive prototypes.",
          duration: "3 weeks",
          level: "Beginner",
          category: "Design",
          skills: ["Figma", "Research", "Prototyping", "UX Writing"],
          color: "amber",
          createdAt: new Date(),
        },
      ]
      const result = await programs.insertMany(seedPrograms.map((p) => ({ ...p, _id: new ObjectId() })))
      const ids = Object.values(result.insertedIds)

      const sampleTasks = [
        // Frontend
        {
          programId: ids[0],
          title: "Build an Accessible Landing Page",
          description:
            "Create a responsive landing page with a hero, features grid, and footer. Ensure semantic HTML and pass Lighthouse accessibility >= 95.",
          rubric: "Semantic HTML, responsive layout, accessibility, code quality.",
          order: 1,
          points: 100,
        },
        {
          programId: ids[0],
          title: "State-Managed Todo App",
          description:
            "Implement a todo app with add/edit/delete/persist. Use React state and explain your data flow in the writeup.",
          rubric: "Correctness, code organization, UX details, writeup clarity.",
          order: 2,
          points: 100,
        },
        // Data
        {
          programId: ids[1],
          title: "SQL: Sales Insights",
          description: "Given the sample sales schema, write 5 queries answering business questions and explain results.",
          rubric: "Query correctness, performance, clarity of insights.",
          order: 1,
          points: 100,
        },
        {
          programId: ids[1],
          title: "Pandas Cleaning Notebook",
          description: "Clean a messy CSV, document your steps, and produce a summary chart with Matplotlib.",
          rubric: "Data quality, documentation, visualization clarity.",
          order: 2,
          points: 100,
        },
        // Design
        {
          programId: ids[2],
          title: "Research Synthesis",
          description: "Conduct 3 user interviews, synthesize findings into a one-page insights doc with quotes.",
          rubric: "Research rigor, synthesis quality, actionable insights.",
          order: 1,
          points: 100,
        },
      ]
      await tasks.insertMany(sampleTasks.map((t) => ({ ...t, _id: new ObjectId(), createdAt: new Date() })))
    }

    seeded = true
  } catch (e) {
    console.warn("[v0] Seed skipped:", (e as Error).message)
  }
}
