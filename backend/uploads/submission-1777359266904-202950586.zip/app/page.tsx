import { SiteNav } from "@/components/site-nav"
import { Hero } from "@/components/landing/hero"
import { Stats } from "@/components/landing/stats"
import { Features } from "@/components/landing/features"
import { How } from "@/components/landing/how"
import { ProgramsPreview } from "@/components/landing/programs-preview"
import { Faq } from "@/components/landing/faq"
import { CtaFooter } from "@/components/landing/cta-footer"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <SiteNav />
      <Hero />
      <Stats />
      <Features />
      <How />
      <ProgramsPreview />
      <Faq />
      <CtaFooter />
    </main>
  )
}
