import Link from "next/link"
import { GraduationCap } from "lucide-react"

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="relative hidden lg:flex flex-col justify-between p-10 bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-20" />
        <div className="absolute -top-20 -left-20 h-96 w-96 rounded-full bg-accent/30 blur-[100px]" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-primary-foreground/10 blur-[100px]" />

        <Link href="/" className="relative flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-foreground text-primary">
            <GraduationCap className="h-5 w-5" />
          </div>
          <span className="font-display font-bold text-lg">RIMP</span>
        </Link>

        <div className="relative">
          <h2 className="font-display text-4xl font-bold tracking-tight text-balance">
            Real internships. Real skills. Real proof.
          </h2>
          <p className="mt-4 text-primary-foreground/80 max-w-md leading-relaxed">
            Join the platform that turns curious learners into hireable engineers, designers, and analysts.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-6">
            <div>
              <div className="font-display text-3xl font-bold">120+</div>
              <div className="text-xs text-primary-foreground/70 mt-1">Programs</div>
            </div>
            <div>
              <div className="font-display text-3xl font-bold">8.4k</div>
              <div className="text-xs text-primary-foreground/70 mt-1">Students</div>
            </div>
            <div>
              <div className="font-display text-3xl font-bold">92%</div>
              <div className="text-xs text-primary-foreground/70 mt-1">Completion</div>
            </div>
          </div>
        </div>

        <div className="relative text-sm text-primary-foreground/60">
          © {new Date().getFullYear()} RIMP — All rights reserved.
        </div>
      </div>

      <div className="flex flex-col">
        <div className="lg:hidden flex items-center justify-between p-4 border-b border-border">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <GraduationCap className="h-4 w-4" />
            </div>
            <span className="font-display font-bold">RIMP</span>
          </Link>
        </div>
        <div className="flex-1 flex items-center justify-center p-6 sm:p-10">
          <div className="w-full max-w-md">{children}</div>
        </div>
      </div>
    </div>
  )
}
