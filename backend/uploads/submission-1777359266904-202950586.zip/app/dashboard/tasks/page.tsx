"use client"

import useSWR from "swr"
import { useEffect, useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  ClipboardCheck,
  Sparkles,
  Loader2,
  CheckCircle2,
  AlertCircle,
  XCircle,
  ChevronRight,
  Clock,
  ShieldAlert,
  Paperclip,
  Wand2,
  FileText,
} from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"
import Link from "next/link"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function TasksPage() {
  const { data: programsData } = useSWR("/api/programs", fetcher)
  const { data, mutate } = useSWR("/api/tasks", fetcher)
  const [openId, setOpenId] = useState<string | null>(null)
  const [text, setText] = useState("")
  const [file, setFile] = useState<{ url: string; name: string; type: string; size: number } | null>(null)
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [generating, setGenerating] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const tasks: any[] = data?.tasks || []
  const enrolledPrograms: any[] = (programsData?.programs || []).filter((p: any) => p.enrolled)

  // Group tasks by program for easier display
  const tasksByProgram = new Map<string, any[]>()
  for (const t of tasks) {
    if (!tasksByProgram.has(t.programId)) tasksByProgram.set(t.programId, [])
    tasksByProgram.get(t.programId)!.push(t)
  }

  // Auto-trigger AI generation for enrolled programs that have zero tasks
  useEffect(() => {
    if (!data || !programsData) return
    for (const p of enrolledPrograms) {
      const has = (tasksByProgram.get(p.id) || []).length > 0
      if (!has && p.taskCount === 0) {
        triggerGenerate(p.id, true)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, programsData])

  async function triggerGenerate(programId: string, silent = false) {
    setGenerating(programId)
    try {
      const res = await fetch("/api/tasks/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ programId }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Failed")
      if (!silent) toast.success(`AI generated ${d.generated} tasks`)
      mutate()
    } catch (e) {
      if (!silent) toast.error((e as Error).message)
    } finally {
      setGenerating(null)
    }
  }

  async function uploadFile(f: File) {
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", f)
      const res = await fetch("/api/upload", { method: "POST", body: fd })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Upload failed")
      setFile({ url: d.url, name: d.name, type: d.type, size: d.size })
      toast.success("File attached")
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setUploading(false)
    }
  }

  async function submit(taskId: string) {
    if (text.trim().length < 20) {
      toast.error("Please write at least 20 characters describing your work.")
      return
    }
    if (!file) {
      toast.error("Please attach a file with your submission.")
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch(`/api/tasks/${taskId}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          submissionText: text,
          fileUrl: file.url,
          fileName: file.name,
          fileType: file.type,
          fileSize: file.size,
        }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Failed to submit")
      const v = d.result.verdict
      if (v === "passed") toast.success(`Passed · ${d.result.score}/100`)
      else if (v === "needs_revision") toast.message(`Needs revision · ${d.result.score}/100`)
      else toast.error(`Did not pass · ${d.result.score}/100`)
      setText("")
      setFile(null)
      setOpenId(null)
      if (fileRef.current) fileRef.current.value = ""
      mutate()
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setSubmitting(false)
    }
  }

  if (!data || !programsData) {
    return <div className="text-muted-foreground">Loading tasks...</div>
  }

  if (enrolledPrograms.length === 0) {
    return (
      <div className="space-y-8">
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Tasks</h1>
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <ClipboardCheck className="h-10 w-10 mx-auto text-muted-foreground" />
          <div className="mt-3 font-display font-semibold">No tasks yet</div>
          <p className="mt-1 text-sm text-muted-foreground">Enroll in a program to unlock tasks.</p>
          <Button asChild className="mt-4">
            <Link href="/dashboard/programs">Browse programs</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Tasks</h1>
        <p className="mt-1 text-muted-foreground">
          Submit your work as a file. Every submission is AI-evaluated and screened for plagiarism.
        </p>
      </div>

      {enrolledPrograms.map((p) => {
        const programTasks = tasksByProgram.get(p.id) || []
        const isGen = generating === p.id
        return (
          <section key={p.id} className="space-y-3">
            <div className="flex items-end justify-between gap-3 flex-wrap">
              <div>
                <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  {p.category} · {p.duration}
                </div>
                <h2 className="font-display text-xl font-bold">{p.title}</h2>
              </div>
              {programTasks.length === 0 && (
                <Button onClick={() => triggerGenerate(p.id)} disabled={isGen} variant="outline" className="bg-transparent">
                  {isGen ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
                  {isGen ? "Generating..." : "Generate AI tasks"}
                </Button>
              )}
            </div>

            {programTasks.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-border p-8 text-center">
                <Sparkles className="h-8 w-8 mx-auto text-primary" />
                <div className="mt-2 font-display font-semibold">
                  {isGen ? "AI is preparing your tasks" : "No tasks from organization yet"}
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  {isGen
                    ? "Hang tight - this usually takes a few seconds."
                    : "Click \"Generate AI tasks\" to instantly create a personalized roadmap."}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {programTasks.map((t, i) => {
                  const isOpen = openId === t.id
                  const sub = t.submission
                  const dueIn = t.deadline ? Math.ceil((new Date(t.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : null
                  return (
                    <motion.div
                      key={t.id}
                      layout
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="rounded-2xl border border-border bg-card overflow-hidden"
                    >
                      <button
                        onClick={() => {
                          setOpenId(isOpen ? null : t.id)
                          setText("")
                          setFile(null)
                          if (fileRef.current) fileRef.current.value = ""
                        }}
                        className="w-full flex items-center gap-4 p-5 text-left hover:bg-muted/40 transition-colors"
                      >
                        <div
                          className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-xl shrink-0",
                            sub?.verdict === "passed"
                              ? "bg-accent/15 text-accent-foreground"
                              : sub?.verdict === "needs_revision"
                                ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                                : sub?.verdict === "failed"
                                  ? "bg-destructive/10 text-destructive"
                                  : "bg-primary/10 text-primary",
                          )}
                        >
                          {sub?.verdict === "passed" ? (
                            <CheckCircle2 className="h-5 w-5" />
                          ) : sub?.verdict === "failed" ? (
                            <XCircle className="h-5 w-5" />
                          ) : sub?.verdict === "needs_revision" ? (
                            <AlertCircle className="h-5 w-5" />
                          ) : (
                            <ClipboardCheck className="h-5 w-5" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                              Task #{t.order}
                            </span>
                            {t.aiGenerated && (
                              <span className="text-[10px] inline-flex items-center gap-1 font-semibold uppercase tracking-wider text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                                <Sparkles className="h-2.5 w-2.5" /> AI
                              </span>
                            )}
                            {t.deadline && (
                              <span
                                className={cn(
                                  "text-[10px] inline-flex items-center gap-1 font-semibold px-1.5 py-0.5 rounded",
                                  dueIn !== null && dueIn < 2
                                    ? "bg-destructive/10 text-destructive"
                                    : dueIn !== null && dueIn < 5
                                      ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                                      : "bg-muted text-muted-foreground",
                                )}
                              >
                                <Clock className="h-2.5 w-2.5" />
                                {dueIn !== null && dueIn >= 0 ? `${dueIn}d left` : "Past due"}
                              </span>
                            )}
                          </div>
                          <div className="font-display font-semibold mt-0.5 truncate">{t.title}</div>
                        </div>
                        <div className="flex items-center gap-3">
                          {sub && (
                            <span
                              className={cn(
                                "text-xs font-mono font-bold px-2 py-1 rounded-full",
                                sub.verdict === "passed"
                                  ? "bg-accent/15 text-accent-foreground"
                                  : sub.verdict === "needs_revision"
                                    ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                                    : "bg-destructive/10 text-destructive",
                              )}
                            >
                              {sub.score}/100
                            </span>
                          )}
                          <ChevronRight className={cn("h-4 w-4 text-muted-foreground transition-transform", isOpen && "rotate-90")} />
                        </div>
                      </button>

                      <AnimatePresence>
                        {isOpen && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden border-t border-border"
                          >
                            <div className="p-6 grid lg:grid-cols-2 gap-6">
                              <div>
                                <h3 className="font-display font-semibold mb-2">Description</h3>
                                <p className="text-sm leading-relaxed text-muted-foreground whitespace-pre-line">
                                  {t.description}
                                </p>
                                {t.rubric && (
                                  <div className="mt-4 rounded-lg bg-muted/50 p-3">
                                    <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                                      Rubric
                                    </div>
                                    <p className="mt-1 text-sm">{t.rubric}</p>
                                  </div>
                                )}
                                {t.deadline && (
                                  <div className="mt-3 text-xs text-muted-foreground inline-flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    Due {new Date(t.deadline).toLocaleDateString(undefined, {
                                      month: "short",
                                      day: "numeric",
                                      year: "numeric",
                                    })}
                                  </div>
                                )}
                                {sub && <FeedbackPanel sub={sub} />}
                              </div>

                              <div>
                                <h3 className="font-display font-semibold mb-2">
                                  {sub ? "Resubmit your work" : "Submit your work"}
                                </h3>
                                <div className="space-y-3">
                                  <div>
                                    <Label htmlFor={`text-${t.id}`}>Writeup</Label>
                                    <Textarea
                                      id={`text-${t.id}`}
                                      rows={6}
                                      placeholder="Describe what you built, decisions, and tradeoffs..."
                                      value={text}
                                      onChange={(e) => setText(e.target.value)}
                                      className="resize-none mt-1.5"
                                    />
                                  </div>

                                  <div>
                                    <Label>Attach file *</Label>
                                    <input
                                      ref={fileRef}
                                      type="file"
                                      hidden
                                      onChange={(e) => {
                                        const f = e.target.files?.[0]
                                        if (f) uploadFile(f)
                                      }}
                                    />
                                    <button
                                      type="button"
                                      onClick={() => fileRef.current?.click()}
                                      className={cn(
                                        "mt-1.5 w-full rounded-lg border-2 border-dashed p-4 text-left transition-colors",
                                        file ? "border-accent/40 bg-accent/5" : "border-border hover:border-primary/40",
                                      )}
                                    >
                                      {file ? (
                                        <div className="flex items-center gap-3">
                                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15 text-accent-foreground shrink-0">
                                            <FileText className="h-4 w-4" />
                                          </div>
                                          <div className="min-w-0 flex-1">
                                            <div className="text-sm font-medium truncate">{file.name}</div>
                                            <div className="text-xs text-muted-foreground">
                                              {(file.size / 1024).toFixed(1)} KB · {file.type || "file"}
                                            </div>
                                          </div>
                                          <span className="text-xs text-primary">Replace</span>
                                        </div>
                                      ) : uploading ? (
                                        <div className="flex items-center gap-3 text-sm">
                                          <Loader2 className="h-4 w-4 animate-spin" /> Uploading...
                                        </div>
                                      ) : (
                                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                                          <Paperclip className="h-4 w-4" />
                                          Click to attach a file (PDF, ZIP, image, video, document)
                                        </div>
                                      )}
                                    </button>
                                  </div>

                                  <Button
                                    onClick={() => submit(t.id)}
                                    disabled={submitting || uploading || !file || text.trim().length < 20}
                                    className="w-full"
                                  >
                                    {submitting ? (
                                      <>
                                        <Loader2 className="h-4 w-4 animate-spin" /> AI is reviewing & screening...
                                      </>
                                    ) : (
                                      <>
                                        <Sparkles className="h-4 w-4" /> Submit for AI review
                                      </>
                                    )}
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  )
                })}
              </div>
            )}
          </section>
        )
      })}
    </div>
  )
}

function FeedbackPanel({ sub }: { sub: any }) {
  const flagged = (sub.plagiarismRisk ?? 0) >= 70
  return (
    <div className="mt-5 rounded-xl border border-border p-4 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">AI Review</span>
        </div>
        <span className="text-xs font-mono font-bold tabular-nums">{sub.score}/100</span>
      </div>
      <p className="mt-2 text-sm leading-relaxed">{sub.feedback}</p>

      {sub.plagiarismRisk !== null && sub.plagiarismRisk !== undefined && (
        <div
          className={cn(
            "mt-3 rounded-lg border px-3 py-2 text-xs flex items-start gap-2",
            flagged ? "border-destructive/30 bg-destructive/5 text-destructive" : "border-border",
          )}
        >
          <ShieldAlert className="h-3.5 w-3.5 mt-0.5 shrink-0" />
          <div>
            <div className="font-semibold">Plagiarism risk: {sub.plagiarismRisk}/100</div>
            {sub.plagiarismNotes && <div className="opacity-80 mt-0.5">{sub.plagiarismNotes}</div>}
          </div>
        </div>
      )}

      {sub.strengths?.length > 0 && (
        <div className="mt-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-accent-foreground">Strengths</div>
          <ul className="mt-1 space-y-1">
            {sub.strengths.map((s: string, i: number) => (
              <li key={i} className="text-xs flex gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-accent shrink-0 mt-0.5" />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {sub.improvements?.length > 0 && (
        <div className="mt-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Improvements</div>
          <ul className="mt-1 space-y-1">
            {sub.improvements.map((s: string, i: number) => (
              <li key={i} className="text-xs flex gap-1.5">
                <AlertCircle className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
