"use client"

import useSWR from "swr"
import { motion } from "framer-motion"
import { Award, Download, GraduationCap } from "lucide-react"
import { Button } from "@/components/ui/button"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function CertificatesPage() {
  const { data } = useSWR("/api/certificates", fetcher)
  const certs: any[] = data?.certificates || []

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Certificates</h1>
        <p className="mt-1 text-muted-foreground">Verified credentials you&apos;ve earned by completing programs.</p>
      </div>

      {certs.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <Award className="h-10 w-10 mx-auto text-muted-foreground" />
          <div className="mt-3 font-display font-semibold">No certificates yet</div>
          <p className="mt-1 text-sm text-muted-foreground max-w-md mx-auto">
            Complete every task in a program with a passing score to unlock your verified certificate.
          </p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {certs.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="relative overflow-hidden rounded-2xl border-2 border-primary/20 bg-gradient-to-br from-card via-card to-primary/5 p-8"
            >
              <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/10 blur-2xl" />
              <div className="absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-primary/10 blur-2xl" />

              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                      <GraduationCap className="h-4 w-4" />
                    </div>
                    <span className="font-display font-bold">RIMP</span>
                  </div>
                  <Award className="h-7 w-7 text-accent-foreground" />
                </div>

                <div className="mt-8">
                  <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                    Certificate of Completion
                  </div>
                  <h3 className="mt-1 font-display text-2xl font-bold leading-tight text-balance">
                    {c.programTitle}
                  </h3>
                </div>

                <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">Awarded to</div>
                    <div className="mt-0.5 font-semibold">{c.studentName}</div>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">Performance</div>
                    <div className="mt-0.5 font-semibold">
                      {c.finalScore}/100 ·{" "}
                      <span className="text-primary">{c.grade || "Pass"}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">Issued</div>
                    <div className="mt-0.5 font-semibold">
                      {new Date(c.issuedAt).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">Credential ID</div>
                    <div className="mt-0.5 font-mono text-xs font-semibold inline-flex items-center gap-1">
                      {c.credentialId}
                      {c.verified && (
                        <span className="ml-1 inline-flex items-center text-[10px] font-bold uppercase tracking-wider text-accent-foreground bg-accent/15 px-1.5 py-0.5 rounded">
                          Verified
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1 bg-transparent"
                    onClick={() => {
                      const url = `${window.location.origin}/verify/${c.credentialId}`
                      navigator.clipboard.writeText(url)
                    }}
                  >
                    Copy verify link
                  </Button>
                  <Button className="flex-1" onClick={() => window.print()}>
                    <Download className="h-4 w-4" /> Download
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
