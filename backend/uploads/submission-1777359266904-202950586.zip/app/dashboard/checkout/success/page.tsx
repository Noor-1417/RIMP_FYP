"use client"

import { Suspense, useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import { Loader2, CheckCircle2, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

function Inner() {
  const router = useRouter()
  const params = useSearchParams()
  const sessionId = params.get("session_id")
  const programId = params.get("program_id")
  const demo = params.get("demo") === "1"
  const [state, setState] = useState<"loading" | "ok" | "err">("loading")
  const [msg, setMsg] = useState("")

  useEffect(() => {
    if (!sessionId) {
      setState("err")
      setMsg("Missing session id")
      return
    }
    ;(async () => {
      try {
        const res = await fetch("/api/checkout/confirm", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId, demo }),
        })
        const d = await res.json()
        if (!res.ok || !d.ok) throw new Error(d.error || "Payment not confirmed")
        // Trigger AI task generation in background
        if (programId) {
          fetch("/api/tasks/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ programId }),
          }).catch(() => {})
        }
        setState("ok")
      } catch (e) {
        setState("err")
        setMsg((e as Error).message)
      }
    })()
  }, [sessionId, programId, demo])

  return (
    <div className="max-w-lg mx-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-2xl border border-border bg-card p-8 text-center"
      >
        {state === "loading" && (
          <>
            <Loader2 className="h-10 w-10 mx-auto animate-spin text-primary" />
            <h1 className="mt-4 font-display text-2xl font-bold">Confirming your payment...</h1>
            <p className="mt-1 text-sm text-muted-foreground">Just a moment.</p>
          </>
        )}
        {state === "ok" && (
          <>
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/15 mx-auto">
              <CheckCircle2 className="h-7 w-7 text-accent-foreground" />
            </div>
            <h1 className="mt-4 font-display text-2xl font-bold">You&apos;re enrolled</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {demo ? "Demo payment approved. " : "Payment confirmed. "}AI is preparing your tasks.
            </p>
            <div className="mt-6 flex gap-2 justify-center">
              <Button onClick={() => router.push("/dashboard/tasks")}>Go to tasks</Button>
              <Button variant="outline" className="bg-transparent" asChild>
                <Link href="/dashboard">Dashboard</Link>
              </Button>
            </div>
          </>
        )}
        {state === "err" && (
          <>
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 mx-auto">
              <XCircle className="h-7 w-7 text-destructive" />
            </div>
            <h1 className="mt-4 font-display text-2xl font-bold">Could not confirm payment</h1>
            <p className="mt-1 text-sm text-muted-foreground">{msg}</p>
            <div className="mt-6 flex gap-2 justify-center">
              <Button asChild>
                <Link href="/dashboard/programs">Back to programs</Link>
              </Button>
            </div>
          </>
        )}
      </motion.div>
    </div>
  )
}

export default function CheckoutSuccessPage() {
  return (
    <Suspense fallback={<div className="text-muted-foreground">Loading...</div>}>
      <Inner />
    </Suspense>
  )
}
