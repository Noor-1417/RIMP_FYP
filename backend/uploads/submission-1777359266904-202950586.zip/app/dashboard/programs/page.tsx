"use client"

import useSWR from "swr"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Search, Clock, CheckCircle2, ArrowRight, Sparkles, Lock, Loader2 } from "lucide-react"
import { toast } from "sonner"
import Link from "next/link"
import { cn } from "@/lib/utils"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

const planOptions = [
  { weeks: 2, label: "2 weeks", priceCents: 0, tag: "Free" },
  { weeks: 4, label: "4 weeks", priceCents: 4900, tag: "$49" },
  { weeks: 8, label: "8 weeks", priceCents: 9900, tag: "$99" },
  { weeks: 12, label: "12 weeks", priceCents: 14900, tag: "$149" },
]

export default function ProgramsPage() {
  const router = useRouter()
  const { data: meData } = useSWR("/api/auth/me", fetcher)
  const { data, mutate } = useSWR("/api/programs", fetcher)
  const [q, setQ] = useState("")
  const [active, setActive] = useState<any | null>(null)
  const [weeks, setWeeks] = useState(2)
  const [busy, setBusy] = useState(false)

  const programs: any[] = data?.programs || []
  const filtered = programs.filter(
    (p) =>
      p.title.toLowerCase().includes(q.toLowerCase()) ||
      (p.skills || []).join(" ").toLowerCase().includes(q.toLowerCase()),
  )

  function openEnroll(p: any) {
    if (meData?.user && !meData.user.hasApplication) {
      toast.error("Complete your application first.")
      router.push("/dashboard/onboarding")
      return
    }
    setActive(p)
    setWeeks(2)
  }

  async function confirmEnroll() {
    if (!active) return
    setBusy(true)
    try {
      const res = await fetch(`/api/programs/${active.id}/enroll`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ durationWeeks: weeks }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Failed to enroll")

      if (d.requiresPayment) {
        const co = await fetch("/api/checkout/create", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ programId: active.id, durationWeeks: weeks }),
        })
        const cd = await co.json()
        if (!co.ok) throw new Error(cd.error || "Failed to start checkout")
        // Redirect to Stripe (or demo success page)
        window.location.href = cd.url
        return
      }

      toast.success("Enrolled — generating your tasks...")
      // Trigger AI task generation if program has none
      if (active.taskCount === 0) {
        fetch("/api/tasks/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ programId: active.id }),
        }).catch(() => {})
      }
      setActive(null)
      mutate()
      router.push("/dashboard/tasks")
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Programs</h1>
        <p className="mt-1 text-muted-foreground">
          Pick a program and choose your pace. 2-week sprint is free; longer mentorship is paid.
        </p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search programs or skills..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9 h-11"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((p, i) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 flex flex-col"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/5 transition-all group-hover:bg-primary/10" />
            <div className="relative flex items-center justify-between mb-4">
              <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">{p.category}</span>
              <span className="text-xs font-semibold rounded-full bg-secondary px-2 py-0.5">{p.level}</span>
            </div>

            <h3 className="relative font-display font-bold text-lg leading-tight text-balance">{p.title}</h3>
            <p className="relative mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-2">{p.summary}</p>

            <div className="relative mt-4 flex flex-wrap gap-1.5">
              {(p.skills || []).slice(0, 4).map((s: string) => (
                <span key={s} className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                  {s}
                </span>
              ))}
            </div>

            <div className="relative mt-5 flex items-center justify-between text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                Up to {p.duration}
              </span>
              <span>{p.taskCount} tasks{p.taskCount === 0 ? " (AI will generate)" : ""}</span>
            </div>

            <div className="relative mt-5">
              {p.enrolled ? (
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/dashboard/tasks">
                    <CheckCircle2 className="h-4 w-4 text-accent" /> Enrolled · Go to tasks
                  </Link>
                </Button>
              ) : (
                <Button className="w-full" onClick={() => openEnroll(p)}>
                  Enroll
                  <ArrowRight className="h-4 w-4" />
                </Button>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {data && filtered.length === 0 && (
        <div className="rounded-2xl border border-dashed border-border p-10 text-center">
          <div className="font-display font-semibold">No programs found</div>
          <p className="mt-1 text-sm text-muted-foreground">Try a different search term.</p>
        </div>
      )}

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Choose your duration</DialogTitle>
            <DialogDescription>
              {active?.title} — pick a track. Longer tracks include extended mentorship and more tasks.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-3">
            {planOptions.map((opt) => {
              const selected = weeks === opt.weeks
              return (
                <button
                  key={opt.weeks}
                  type="button"
                  onClick={() => setWeeks(opt.weeks)}
                  className={cn(
                    "relative rounded-xl border p-4 text-left transition-all",
                    selected
                      ? "border-primary bg-primary/5 ring-2 ring-primary/30"
                      : "border-border hover:border-primary/40",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div className="font-display font-bold">{opt.label}</div>
                    <span
                      className={cn(
                        "text-xs font-semibold rounded-full px-2 py-0.5",
                        opt.priceCents === 0 ? "bg-accent/15 text-accent-foreground" : "bg-amber-500/15 text-amber-700 dark:text-amber-300",
                      )}
                    >
                      {opt.tag}
                    </span>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    {opt.priceCents === 0 ? (
                      <span className="inline-flex items-center gap-1">
                        <Sparkles className="h-3 w-3" /> Free starter sprint
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1">
                        <Lock className="h-3 w-3" /> Paid · Stripe checkout
                      </span>
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setActive(null)} disabled={busy}>
              Cancel
            </Button>
            <Button onClick={confirmEnroll} disabled={busy}>
              {busy ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Working...
                </>
              ) : weeks <= 2 ? (
                <>Start free sprint</>
              ) : (
                <>Continue to payment</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
