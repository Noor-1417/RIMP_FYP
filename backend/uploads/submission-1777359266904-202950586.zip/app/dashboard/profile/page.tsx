"use client"

import useSWR from "swr"
import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Download, Pencil, Mail, Phone, MapPin, GraduationCap, Briefcase, Globe, Linkedin, Github } from "lucide-react"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function ProfilePage() {
  const { data } = useSWR("/api/applications", fetcher)
  const a = data?.application

  if (data && !a) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-12 text-center">
        <div className="font-display font-semibold">No application on file</div>
        <p className="mt-1 text-sm text-muted-foreground">Complete your application to view your profile and CV.</p>
        <Button asChild className="mt-4">
          <Link href="/dashboard/onboarding">Start application</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Profile</h1>
          <p className="mt-1 text-muted-foreground">Submitted application details. Download your CV anytime.</p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" className="bg-transparent">
            <Link href="/dashboard/onboarding">
              <Pencil className="h-4 w-4" /> Edit
            </Link>
          </Button>
          <Button asChild>
            <a href="/api/applications/me/cv" target="_blank" rel="noreferrer">
              <Download className="h-4 w-4" /> Download CV
            </a>
          </Button>
        </div>
      </div>

      {a && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid gap-6 lg:grid-cols-3"
        >
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-primary-foreground text-xl font-bold">
                  {a.fullName
                    ?.split(" ")
                    .map((p: string) => p[0])
                    .slice(0, 2)
                    .join("")
                    .toUpperCase()}
                </div>
                <div>
                  <div className="font-display text-2xl font-bold">{a.fullName}</div>
                  {a.headline && <div className="text-muted-foreground">{a.headline}</div>}
                </div>
              </div>

              <div className="mt-6 grid gap-3 sm:grid-cols-2 text-sm">
                <Row icon={Mail} label="Email" value={a.email} />
                <Row icon={Phone} label="Phone" value={a.phone} />
                <Row icon={MapPin} label="Location" value={a.location} />
                <Row icon={GraduationCap} label="Education" value={`${a.degree || ""} · ${a.university || ""}`} />
                {a.linkedin && <Row icon={Linkedin} label="LinkedIn" value={a.linkedin} link />}
                {a.github && <Row icon={Github} label="GitHub" value={a.github} link />}
                {a.portfolio && <Row icon={Globe} label="Portfolio" value={a.portfolio} link />}
              </div>

              {a.bio && (
                <div className="mt-6">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">About</div>
                  <p className="mt-1 text-sm leading-relaxed">{a.bio}</p>
                </div>
              )}
            </div>

            {a.experience && (
              <div className="rounded-2xl border border-border bg-card p-6">
                <h2 className="font-display font-bold flex items-center gap-2">
                  <Briefcase className="h-4 w-4 text-primary" /> Experience
                </h2>
                <p className="mt-3 text-sm leading-relaxed whitespace-pre-line">{a.experience}</p>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Skills</div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {(a.skills || []).map((s: string) => (
                  <span key={s} className="text-xs px-2 py-1 rounded-full bg-secondary font-medium">
                    {s}
                  </span>
                ))}
                {(!a.skills || a.skills.length === 0) && (
                  <span className="text-sm text-muted-foreground italic">No skills listed</span>
                )}
              </div>
            </div>

            {a.achievements && (
              <div className="rounded-2xl border border-border bg-card p-6">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Achievements</div>
                <p className="mt-2 text-sm leading-relaxed whitespace-pre-line">{a.achievements}</p>
              </div>
            )}

            <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5 p-6">
              <div className="font-display font-bold">Your generated CV</div>
              <p className="text-sm text-muted-foreground mt-1">
                A clean, ATS-friendly PDF built from your application.
              </p>
              <Button asChild className="mt-4 w-full">
                <a href="/api/applications/me/cv" target="_blank" rel="noreferrer">
                  <Download className="h-4 w-4" /> Download CV
                </a>
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  )
}

function Row({
  icon: Icon,
  label,
  value,
  link,
}: {
  icon: any
  label: string
  value?: string
  link?: boolean
}) {
  if (!value) return null
  return (
    <div className="flex items-start gap-2">
      <Icon className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
      <div className="min-w-0">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        {link ? (
          <a
            href={value.startsWith("http") ? value : `https://${value}`}
            target="_blank"
            rel="noreferrer"
            className="font-medium text-primary hover:underline truncate block"
          >
            {value}
          </a>
        ) : (
          <div className="font-medium truncate">{value}</div>
        )}
      </div>
    </div>
  )
}
