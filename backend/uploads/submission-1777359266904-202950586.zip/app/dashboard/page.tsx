"use client"

import useSWR from "swr"
import Link from "next/link"
import { motion } from "framer-motion"
import { BookOpen, ClipboardCheck, Award, ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function StudentDashboard() {
  const { data: meData } = useSWR("/api/auth/me", fetcher)
  const { data: programsData } = useSWR("/api/programs", fetcher)
  const { data: tasksData } = useSWR("/api/tasks", fetcher)
  const { data: certData } = useSWR("/api/certificates", fetcher)

  const me = meData?.user
  const programs = programsData?.programs || []
  const enrolled = programs.filter((p: any) => p.enrolled)
  const tasks = tasksData?.tasks || []
  const submittedTasks = tasks.filter((t: any) => t.submission)
  const passedTasks = tasks.filter((t: any) => t.submission?.verdict === "passed")
  const certificates = certData?.certificates || []

  const stats = [
    { label: "Enrolled", value: enrolled.length, icon: BookOpen, accent: "text-primary bg-primary/10" },
    {
      label: "Submitted",
      value: submittedTasks.length,
      icon: ClipboardCheck,
      accent: "text-accent-foreground bg-accent/15",
    },
    {
      label: "Passed",
      value: passedTasks.length,
      icon: Sparkles,
      accent: "text-amber-700 bg-amber-100 dark:bg-amber-500/15 dark:text-amber-300",
    },
    { label: "Certificates", value: certificates.length, icon: Award, accent: "text-primary bg-primary/10" },
  ]

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
            Hey {me?.name?.split(" ")[0] || "there"} 
          </h1>
          <p className="mt-1 text-muted-foreground">Here&apos;s what&apos;s happening in your internships today.</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/programs">
            Browse programs
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-2xl border border-border bg-card p-5"
          >
            <div className="flex items-center justify-between">
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${s.accent}`}>
                <s.icon className="h-5 w-5" />
              </div>
              <div className="text-3xl font-display font-bold tabular-nums">{s.value}</div>
            </div>
            <div className="mt-3 text-sm text-muted-foreground">{s.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-xl">Your active programs</h2>
            <Button asChild size="sm" variant="ghost">
              <Link href="/dashboard/programs">View all</Link>
            </Button>
          </div>

          {enrolled.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center py-10 px-6 rounded-xl border border-dashed border-border">
              <BookOpen className="h-10 w-10 text-muted-foreground" />
              <div className="mt-3 font-display font-semibold">No programs yet</div>
              <p className="mt-1 text-sm text-muted-foreground max-w-sm">
                Enroll in a program to start completing tasks and earning your certificate.
              </p>
              <Button asChild className="mt-4">
                <Link href="/dashboard/programs">Browse programs</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {enrolled.map((p: any) => {
                const progPassed = passedTasks.filter((t: any) => t.programId === p.id).length
                const progress = p.taskCount ? Math.round((progPassed / p.taskCount) * 100) : 0
                return (
                  <div key={p.id} className="rounded-xl border border-border p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="min-w-0">
                        <div className="font-display font-semibold truncate">{p.title}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {progPassed}/{p.taskCount} tasks passed · {p.duration}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-mono font-semibold">{progress}%</div>
                      </div>
                    </div>
                    <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="h-full bg-primary"
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display font-bold text-xl mb-4">Recent feedback</h2>
          {submittedTasks.length === 0 ? (
            <div className="text-sm text-muted-foreground">
              Submit a task and you&apos;ll see AI feedback here.
            </div>
          ) : (
            <div className="space-y-3">
              {submittedTasks.slice(0, 4).map((t: any) => (
                <div key={t.id} className="rounded-xl border border-border p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="font-semibold text-sm truncate">{t.title}</div>
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded-full ${
                        t.submission.verdict === "passed"
                          ? "bg-accent/15 text-accent-foreground"
                          : t.submission.verdict === "needs_revision"
                            ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                            : "bg-destructive/10 text-destructive"
                      }`}
                    >
                      {t.submission.score}/100
                    </span>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                    {t.submission.feedback}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
