"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import useSWR from "swr"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle2, ChevronLeft, ChevronRight, Loader2, FileText, GraduationCap, Briefcase, User } from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

const steps = [
  { id: "personal", label: "Personal", icon: User },
  { id: "education", label: "Education", icon: GraduationCap },
  { id: "professional", label: "Professional", icon: Briefcase },
  { id: "review", label: "Review", icon: FileText },
] as const

export default function OnboardingPage() {
  const router = useRouter()
  const { data: meData } = useSWR("/api/auth/me", fetcher)
  const { data: appData, mutate } = useSWR("/api/applications", fetcher)
  const [step, setStep] = useState(0)
  const [saving, setSaving] = useState(false)

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    location: "",
    dob: "",
    headline: "",
    bio: "",
    university: "",
    degree: "",
    graduationYear: "",
    gpa: "",
    skills: "",
    experience: "",
    portfolio: "",
    linkedin: "",
    github: "",
    achievements: "",
  })

  // Prefill from existing application or auth
  useEffect(() => {
    const a = appData?.application
    if (a) {
      setForm({
        fullName: a.fullName || "",
        email: a.email || "",
        phone: a.phone || "",
        location: a.location || "",
        dob: a.dob || "",
        headline: a.headline || "",
        bio: a.bio || "",
        university: a.university || "",
        degree: a.degree || "",
        graduationYear: a.graduationYear || "",
        gpa: a.gpa || "",
        skills: Array.isArray(a.skills) ? a.skills.join(", ") : a.skills || "",
        experience: a.experience || "",
        portfolio: a.portfolio || "",
        linkedin: a.linkedin || "",
        github: a.github || "",
        achievements: a.achievements || "",
      })
    } else if (meData?.user) {
      setForm((f) => ({ ...f, fullName: f.fullName || meData.user.name, email: f.email || meData.user.email }))
    }
  }, [appData, meData])

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function validateStep(idx: number): string | null {
    if (idx === 0) {
      if (!form.fullName) return "Full name is required."
      if (!form.email) return "Email is required."
      if (!form.phone) return "Phone is required."
      if (!form.location) return "Location is required."
    }
    if (idx === 1) {
      if (!form.university) return "University is required."
      if (!form.degree) return "Degree is required."
    }
    return null
  }

  async function submit() {
    setSaving(true)
    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Failed to submit")
      toast.success("Application submitted")
      mutate()
      router.push("/dashboard")
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  function next() {
    const err = validateStep(step)
    if (err) return toast.error(err)
    setStep((s) => Math.min(steps.length - 1, s + 1))
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Complete your application</h1>
        <p className="mt-1 text-muted-foreground">
          Tell us about yourself. Your details are shared with the organization and used to generate your CV.
        </p>
      </div>

      {/* Stepper */}
      <ol className="flex items-center gap-1.5">
        {steps.map((s, i) => {
          const done = i < step
          const active = i === step
          return (
            <li key={s.id} className="flex-1">
              <button
                type="button"
                onClick={() => i < step && setStep(i)}
                className={cn(
                  "w-full flex items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "border-primary bg-primary/10 text-primary"
                    : done
                      ? "border-accent/40 bg-accent/10 text-accent-foreground"
                      : "border-border bg-card text-muted-foreground",
                )}
              >
                <div
                  className={cn(
                    "flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold",
                    active
                      ? "bg-primary text-primary-foreground"
                      : done
                        ? "bg-accent text-accent-foreground"
                        : "bg-muted text-muted-foreground",
                  )}
                >
                  {done ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
                </div>
                <span className="hidden sm:inline">{s.label}</span>
              </button>
            </li>
          )
        })}
      </ol>

      <motion.div
        key={step}
        initial={{ opacity: 0, x: 12 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.25 }}
        className="rounded-2xl border border-border bg-card p-6 sm:p-8"
      >
        {step === 0 && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Full name *">
              <Input value={form.fullName} onChange={(e) => update("fullName", e.target.value)} />
            </Field>
            <Field label="Email *">
              <Input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} />
            </Field>
            <Field label="Phone *">
              <Input value={form.phone} onChange={(e) => update("phone", e.target.value)} />
            </Field>
            <Field label="Location *">
              <Input
                placeholder="City, Country"
                value={form.location}
                onChange={(e) => update("location", e.target.value)}
              />
            </Field>
            <Field label="Date of birth">
              <Input type="date" value={form.dob} onChange={(e) => update("dob", e.target.value)} />
            </Field>
            <Field label="Headline">
              <Input
                placeholder="e.g. Aspiring Frontend Engineer"
                value={form.headline}
                onChange={(e) => update("headline", e.target.value)}
              />
            </Field>
            <div className="sm:col-span-2">
              <Field label="Short bio">
                <Textarea
                  rows={4}
                  placeholder="A few sentences about yourself, interests, and goals."
                  value={form.bio}
                  onChange={(e) => update("bio", e.target.value)}
                />
              </Field>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="University *">
              <Input value={form.university} onChange={(e) => update("university", e.target.value)} />
            </Field>
            <Field label="Degree *">
              <Input
                placeholder="e.g. BSc Computer Science"
                value={form.degree}
                onChange={(e) => update("degree", e.target.value)}
              />
            </Field>
            <Field label="Graduation year">
              <Input value={form.graduationYear} onChange={(e) => update("graduationYear", e.target.value)} />
            </Field>
            <Field label="GPA">
              <Input value={form.gpa} onChange={(e) => update("gpa", e.target.value)} />
            </Field>
            <div className="sm:col-span-2">
              <Field label="Achievements / awards">
                <Textarea
                  rows={3}
                  placeholder="Hackathons, scholarships, dean's list, certifications..."
                  value={form.achievements}
                  onChange={(e) => update("achievements", e.target.value)}
                />
              </Field>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Field label="Skills (comma separated)">
                <Input
                  placeholder="React, TypeScript, Python..."
                  value={form.skills}
                  onChange={(e) => update("skills", e.target.value)}
                />
              </Field>
            </div>
            <div className="sm:col-span-2">
              <Field label="Experience">
                <Textarea
                  rows={5}
                  placeholder="Past internships, projects, freelance work..."
                  value={form.experience}
                  onChange={(e) => update("experience", e.target.value)}
                />
              </Field>
            </div>
            <Field label="Portfolio URL">
              <Input value={form.portfolio} onChange={(e) => update("portfolio", e.target.value)} />
            </Field>
            <Field label="LinkedIn">
              <Input value={form.linkedin} onChange={(e) => update("linkedin", e.target.value)} />
            </Field>
            <Field label="GitHub">
              <Input value={form.github} onChange={(e) => update("github", e.target.value)} />
            </Field>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="font-display text-xl font-bold">Review your application</h2>
            <div className="grid gap-4 sm:grid-cols-2 text-sm">
              <Summary label="Full name" value={form.fullName} />
              <Summary label="Email" value={form.email} />
              <Summary label="Phone" value={form.phone} />
              <Summary label="Location" value={form.location} />
              <Summary label="University" value={form.university} />
              <Summary label="Degree" value={form.degree} />
              <Summary label="Graduation" value={form.graduationYear} />
              <Summary label="GPA" value={form.gpa} />
              <div className="sm:col-span-2">
                <Summary label="Skills" value={form.skills} />
              </div>
              <div className="sm:col-span-2">
                <Summary label="Bio" value={form.bio} />
              </div>
              <div className="sm:col-span-2">
                <Summary label="Experience" value={form.experience} />
              </div>
            </div>
            <div className="rounded-xl border border-dashed border-primary/30 bg-primary/5 p-4 text-sm">
              By submitting, your information is sent to the organization. You can download a generated PDF CV from
              your profile page after submission.
            </div>
          </div>
        )}

        <div className="mt-8 flex items-center justify-between gap-3">
          <Button
            type="button"
            variant="ghost"
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            disabled={step === 0 || saving}
          >
            <ChevronLeft className="h-4 w-4" /> Back
          </Button>
          {step < steps.length - 1 ? (
            <Button type="button" onClick={next}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={submit} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Submitting...
                </>
              ) : (
                <>Submit application</>
              )}
            </Button>
          )}
        </div>
      </motion.div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      <div className="mt-1.5">{children}</div>
    </div>
  )
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-0.5 font-medium">{value || <span className="text-muted-foreground italic">Not provided</span>}</div>
    </div>
  )
}
