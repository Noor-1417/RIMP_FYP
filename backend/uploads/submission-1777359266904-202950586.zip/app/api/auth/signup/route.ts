import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { getCollections } from "@/lib/mongodb"
import { createSessionToken, setSessionCookie } from "@/lib/auth"
import { ensureSeed } from "@/lib/seed"
import { ObjectId } from "mongodb"

export async function POST(req: Request) {
  try {
    await ensureSeed()
    const { name, email, password, role } = await req.json()

    if (!email || !password || !name) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 })
    }
    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters" }, { status: 400 })
    }

    const { users } = await getCollections()
    const lower = String(email).toLowerCase().trim()
    const existing = await users.findOne({ email: lower })
    if (existing) {
      return NextResponse.json({ error: "Email already registered" }, { status: 409 })
    }

    const passwordHash = await bcrypt.hash(password, 10)
    const finalRole = role === "admin" ? "admin" : "student"
    const _id = new ObjectId()
    await users.insertOne({
      _id,
      email: lower,
      name,
      passwordHash,
      role: finalRole,
      createdAt: new Date(),
    })

    const token = await createSessionToken({
      sub: _id.toString(),
      email: lower,
      name,
      role: finalRole,
    })
    await setSessionCookie(token)

    return NextResponse.json({
      user: { id: _id.toString(), email: lower, name, role: finalRole },
    })
  } catch (e) {
    console.log("[v0] signup error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
