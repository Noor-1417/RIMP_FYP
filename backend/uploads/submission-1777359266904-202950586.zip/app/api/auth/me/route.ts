import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getCollections } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ user: null })
  let hasApplication = false
  try {
    if (session.role === "student") {
      const { applications } = await getCollections()
      const app = await applications.findOne({ userId: new ObjectId(session.sub) })
      hasApplication = !!app
    } else {
      hasApplication = true
    }
  } catch {
    // ignore - if DB is down user can still see app
  }
  return NextResponse.json({
    user: {
      id: session.sub,
      email: session.email,
      name: session.name,
      role: session.role,
      hasApplication,
    },
  })
}
