import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { getCollections } from "@/lib/mongodb"
import { createSessionToken, setSessionCookie } from "@/lib/auth"
import { ensureSeed } from "@/lib/seed"

export async function POST(req: Request) {
  try {
    await ensureSeed()
    const { email, password } = await req.json()
    if (!email || !password) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 })
    }
    const { users } = await getCollections()
    const lower = String(email).toLowerCase().trim()
    const user = await users.findOne({ email: lower })
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }
    const ok = await bcrypt.compare(password, user.passwordHash)
    if (!ok) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }
    const token = await createSessionToken({
      sub: user._id.toString(),
      email: user.email,
      name: user.name,
      role: user.role,
    })
    await setSessionCookie(token)
    return NextResponse.json({
      user: { id: user._id.toString(), email: user.email, name: user.name, role: user.role },
    })
  } catch (e) {
    console.log("[v0] login error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
