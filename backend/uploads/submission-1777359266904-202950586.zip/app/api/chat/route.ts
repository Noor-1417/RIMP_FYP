import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { chatWithMentor } from "@/lib/groq"

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { messages, context } = await req.json()
    if (!Array.isArray(messages)) {
      return NextResponse.json({ error: "messages must be an array" }, { status: 400 })
    }
    let reply
    try {
      reply = await chatWithMentor({ history: messages, context })
    } catch (e) {
      reply = `I'm offline right now (GROQ_API_KEY not configured). Add the Groq integration to chat with the AI mentor. (${(e as Error).message})`
    }
    return NextResponse.json({ reply })
  } catch (e) {
    console.log("[v0] chat error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
