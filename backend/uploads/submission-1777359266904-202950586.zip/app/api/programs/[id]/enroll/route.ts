import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { priceForDurationWeeks } from "@/lib/stripe"
import { ObjectId } from "mongodb"

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { id } = await params
    const body = await req.json().catch(() => ({}))
    const durationWeeks = Math.max(1, Math.min(52, Number(body.durationWeeks) || 2))

    const { enrollments, programs, applications } = await getCollections()
    const programId = new ObjectId(id)
    const program = await programs.findOne({ _id: programId })
    if (!program) return NextResponse.json({ error: "Program not found" }, { status: 404 })

    const userId = new ObjectId(session.sub)

    // Require completed application before enrolling
    const app = await applications.findOne({ userId })
    if (!app) {
      return NextResponse.json(
        { error: "Please complete your application first.", needsApplication: true },
        { status: 400 },
      )
    }

    const existing = await enrollments.findOne({ userId, programId })
    if (existing && existing.status !== "pending_payment") {
      return NextResponse.json({ ok: true, alreadyEnrolled: true })
    }

    const priceCents = priceForDurationWeeks(durationWeeks)
    const status: "active" | "pending_payment" = priceCents === 0 ? "active" : "pending_payment"

    await enrollments.updateOne(
      { userId, programId },
      {
        $set: {
          userId,
          programId,
          status,
          progress: 0,
          durationWeeks,
          priceCents,
          enrolledAt: new Date(),
        },
        $setOnInsert: { _id: new ObjectId() },
      },
      { upsert: true },
    )

    return NextResponse.json({
      ok: true,
      requiresPayment: priceCents > 0,
      priceCents,
      durationWeeks,
    })
  } catch (e) {
    console.log("[v0] enroll error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
