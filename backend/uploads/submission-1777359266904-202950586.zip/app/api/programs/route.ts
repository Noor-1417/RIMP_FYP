import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { ensureSeed } from "@/lib/seed"
import { ObjectId } from "mongodb"

export async function GET() {
  try {
    await ensureSeed()
    const { programs, tasks, enrollments } = await getCollections()
    const session = await getSession()
    const allPrograms = await programs.find({}).sort({ createdAt: -1 }).toArray()

    const programIds = allPrograms.map((p) => p._id)
    const allTasks = await tasks.find({ programId: { $in: programIds } }).toArray()
    const tasksByProgram = new Map<string, number>()
    for (const t of allTasks) {
      const k = t.programId.toString()
      tasksByProgram.set(k, (tasksByProgram.get(k) || 0) + 1)
    }

    let enrolledIds = new Set<string>()
    if (session) {
      const enrolls = await enrollments.find({ userId: new ObjectId(session.sub) }).toArray()
      enrolledIds = new Set(enrolls.map((e) => e.programId.toString()))
    }

    return NextResponse.json({
      programs: allPrograms.map((p) => ({
        id: p._id.toString(),
        title: p.title,
        slug: p.slug,
        summary: p.summary,
        duration: p.duration,
        level: p.level,
        category: p.category,
        skills: p.skills || [],
        color: p.color || "indigo",
        taskCount: tasksByProgram.get(p._id.toString()) || 0,
        enrolled: enrolledIds.has(p._id.toString()),
      })),
    })
  } catch (e) {
    console.log("[v0] programs GET error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message, programs: [] }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    const body = await req.json()
    const { programs } = await getCollections()
    const _id = new ObjectId()
    await programs.insertOne({
      _id,
      title: body.title,
      slug: (body.title || "").toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
      summary: body.summary,
      duration: body.duration || "4 weeks",
      level: body.level || "Beginner",
      category: body.category || "Engineering",
      skills: Array.isArray(body.skills) ? body.skills : String(body.skills || "").split(",").map((s: string) => s.trim()).filter(Boolean),
      color: body.color || "indigo",
      createdAt: new Date(),
    })
    return NextResponse.json({ id: _id.toString() })
  } catch (e) {
    console.log("[v0] programs POST error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
