import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET() {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { applications } = await getCollections()
    const app = await applications.findOne({ userId: new ObjectId(session.sub) })
    if (!app) return NextResponse.json({ application: null })
    return NextResponse.json({
      application: {
        ...app,
        _id: app._id.toString(),
        userId: app.userId.toString(),
      },
    })
  } catch (e) {
    console.log("[v0] application GET error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const body = await req.json()

    const required = ["fullName", "email", "phone", "location", "university", "degree"]
    for (const k of required) {
      if (!body[k]) return NextResponse.json({ error: `Missing field: ${k}` }, { status: 400 })
    }

    const { applications } = await getCollections()
    const userId = new ObjectId(session.sub)
    const skills = Array.isArray(body.skills)
      ? body.skills
      : String(body.skills || "")
          .split(",")
          .map((s: string) => s.trim())
          .filter(Boolean)

    const doc = {
      userId,
      fullName: body.fullName,
      email: body.email,
      phone: body.phone || "",
      location: body.location || "",
      dob: body.dob || "",
      university: body.university || "",
      degree: body.degree || "",
      graduationYear: body.graduationYear || "",
      gpa: body.gpa || "",
      headline: body.headline || "",
      bio: body.bio || "",
      skills,
      experience: body.experience || "",
      portfolio: body.portfolio || "",
      linkedin: body.linkedin || "",
      github: body.github || "",
      achievements: body.achievements || "",
      submittedAt: new Date(),
    }

    await applications.updateOne(
      { userId },
      { $set: doc, $setOnInsert: { _id: new ObjectId() } },
      { upsert: true },
    )
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.log("[v0] application POST error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
