import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { ObjectId } from "mongodb"
import { buildCvPdf } from "@/lib/pdf"

export async function GET() {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { applications } = await getCollections()
    const app = await applications.findOne({ userId: new ObjectId(session.sub) })
    if (!app) return NextResponse.json({ error: "Submit your application first." }, { status: 404 })

    const bytes = buildCvPdf({
      fullName: app.fullName,
      email: app.email,
      phone: app.phone,
      location: app.location,
      dob: app.dob,
      university: app.university,
      degree: app.degree,
      graduationYear: app.graduationYear,
      gpa: app.gpa,
      headline: app.headline,
      bio: app.bio,
      skills: app.skills || [],
      experience: app.experience,
      portfolio: app.portfolio,
      linkedin: app.linkedin,
      github: app.github,
      achievements: app.achievements,
    })

    const safeName = (app.fullName || "candidate").replace(/[^a-z0-9]+/gi, "_")
    return new NextResponse(bytes as any, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${safeName}_CV.pdf"`,
        "Cache-Control": "no-store",
      },
    })
  } catch (e) {
    console.log("[v0] cv error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
