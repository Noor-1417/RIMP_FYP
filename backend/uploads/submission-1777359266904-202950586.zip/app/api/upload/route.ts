import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { put } from "@vercel/blob"

export const runtime = "nodejs"

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const form = await req.formData()
    const file = form.get("file") as File | null
    if (!file) return NextResponse.json({ error: "No file" }, { status: 400 })

    const maxBytes = 15 * 1024 * 1024
    if (file.size > maxBytes) {
      return NextResponse.json({ error: "File too large (max 15 MB)" }, { status: 413 })
    }

    const safe = (file.name || "submission").replace(/[^a-z0-9._-]+/gi, "_")
    const key = `submissions/${session.sub}/${Date.now()}-${safe}`

    if (!process.env.BLOB_READ_WRITE_TOKEN) {
      // Graceful fallback: return a data URL so the UI still works for demos
      const buf = Buffer.from(await file.arrayBuffer())
      const dataUrl = `data:${file.type || "application/octet-stream"};base64,${buf.toString("base64")}`
      return NextResponse.json({
        url: dataUrl,
        name: file.name,
        size: file.size,
        type: file.type,
        storage: "data-url",
        warning: "BLOB_READ_WRITE_TOKEN not set. File stored inline (demo mode).",
      })
    }

    const blob = await put(key, file, {
      access: "public",
      contentType: file.type || undefined,
    })
    return NextResponse.json({
      url: blob.url,
      name: file.name,
      size: file.size,
      type: file.type,
      storage: "blob",
    })
  } catch (e) {
    console.log("[v0] upload error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
