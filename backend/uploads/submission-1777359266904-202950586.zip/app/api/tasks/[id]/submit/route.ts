import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { evaluateSubmission } from "@/lib/groq"
import { ObjectId } from "mongodb"

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { id } = await params
    const { submissionText, fileUrl, fileName, fileType, fileSize } = await req.json()
    if (!submissionText || submissionText.trim().length < 20) {
      return NextResponse.json({ error: "Writeup must be at least 20 characters." }, { status: 400 })
    }
    if (!fileUrl) {
      return NextResponse.json({ error: "Please attach a file with your work." }, { status: 400 })
    }

    const { tasks, submissions, enrollments, certificates, programs } = await getCollections()
    const taskId = new ObjectId(id)
    const userId = new ObjectId(session.sub)
    const task = await tasks.findOne({ _id: taskId })
    if (!task) return NextResponse.json({ error: "Task not found" }, { status: 404 })

    const fileSummary = `Attached: ${fileName || "file"} (${fileType || "unknown type"}, ${
      fileSize ? Math.round(fileSize / 1024) + " KB" : "size unknown"
    })`

    let evalResult
    try {
      evalResult = await evaluateSubmission({
        taskTitle: task.title,
        taskDescription: task.description,
        rubric: task.rubric,
        submissionText,
        fileSummary,
        studentName: session.name,
      })
    } catch (e) {
      console.log("[v0] groq error - using fallback:", (e as Error).message)
      const len = submissionText.trim().length
      const score = Math.min(95, 50 + Math.floor(len / 30))
      evalResult = {
        score,
        verdict: score >= 70 ? "passed" : score >= 50 ? "needs_revision" : "failed",
        strengths: ["Effort and clarity in writing.", "Submission attached."],
        improvements: ["Configure GROQ_API_KEY for AI-powered review.", "Add concrete examples and code snippets."],
        feedback: "Heuristic review (Groq AI not configured). Add GROQ_API_KEY for richer feedback.",
        plagiarismRisk: 5,
        plagiarismNotes: "Plagiarism check skipped (Groq not configured).",
      } as const
    }

    // If high plagiarism risk, downgrade verdict
    let finalVerdict = evalResult.verdict
    if (evalResult.plagiarismRisk >= 70 && finalVerdict === "passed") finalVerdict = "needs_revision"
    if (evalResult.plagiarismRisk >= 90) finalVerdict = "failed"

    await submissions.updateOne(
      { userId, taskId },
      {
        $set: {
          userId,
          taskId,
          programId: task.programId,
          submissionText,
          fileUrl,
          fileName: fileName || "submission",
          fileType: fileType || "application/octet-stream",
          fileSize: fileSize || 0,
          score: evalResult.score,
          verdict: finalVerdict,
          strengths: evalResult.strengths,
          improvements: evalResult.improvements,
          feedback: evalResult.feedback,
          plagiarismRisk: evalResult.plagiarismRisk,
          plagiarismNotes: evalResult.plagiarismNotes,
          flagged: evalResult.plagiarismRisk >= 70,
          studentName: session.name,
          studentEmail: session.email,
          submittedAt: new Date(),
        },
      },
      { upsert: true },
    )

    // Update enrollment progress; pass requires score >= 70 and not failed verdict
    const programTasks = await tasks.find({ programId: task.programId }).toArray()
    const programTaskIds = programTasks.map((t) => t._id)
    const passedSubs = await submissions
      .find({ userId, taskId: { $in: programTaskIds }, verdict: "passed" })
      .toArray()
    const progress = Math.round((passedSubs.length / programTasks.length) * 100)

    await enrollments.updateOne(
      { userId, programId: task.programId },
      {
        $set: { progress, status: progress === 100 ? "completed" : "active" },
        $setOnInsert: { _id: new ObjectId(), userId, programId: task.programId, enrolledAt: new Date() },
      },
      { upsert: true },
    )

    if (progress === 100) {
      const program = await programs.findOne({ _id: task.programId })
      const existing = await certificates.findOne({ userId, programId: task.programId })
      if (!existing && program) {
        const avg = passedSubs.reduce((acc, s) => acc + (s.score || 0), 0) / Math.max(1, passedSubs.length)
        const grade = avg >= 90 ? "Distinction" : avg >= 80 ? "Excellence" : avg >= 70 ? "Merit" : "Pass"
        await certificates.insertOne({
          _id: new ObjectId(),
          userId,
          programId: task.programId,
          programTitle: program.title,
          studentName: session.name,
          finalScore: Math.round(avg),
          grade,
          credentialId: `RIMP-${Date.now().toString(36).toUpperCase()}`,
          verified: true,
          issuedAt: new Date(),
        })
      }
    }

    return NextResponse.json({ result: { ...evalResult, verdict: finalVerdict }, progress })
  } catch (e) {
    console.log("[v0] submit error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
