import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { searchParams } = new URL(req.url)
    const programId = searchParams.get("programId")

    const { tasks, submissions, enrollments, programs } = await getCollections()
    const userId = new ObjectId(session.sub)

    let programFilter: any = {}
    let activeProgramIds: ObjectId[] = []
    if (programId) {
      programFilter = { programId: new ObjectId(programId) }
      activeProgramIds = [new ObjectId(programId)]
    } else {
      const enrolls = await enrollments.find({ userId, status: { $ne: "pending_payment" } }).toArray()
      activeProgramIds = enrolls.map((e) => e.programId)
      programFilter = { programId: { $in: activeProgramIds } }
    }

    const allTasks = await tasks.find(programFilter).sort({ order: 1 }).toArray()
    const allSubs = await submissions.find({ userId, taskId: { $in: allTasks.map((t) => t._id) } }).toArray()
    const subByTask = new Map(allSubs.map((s) => [s.taskId.toString(), s]))

    const programIds = Array.from(new Set(allTasks.map((t) => t.programId.toString())))
    const allPrograms = await programs.find({ _id: { $in: programIds.map((id) => new ObjectId(id)) } }).toArray()
    const programMap = new Map(allPrograms.map((p) => [p._id.toString(), p]))

    return NextResponse.json({
      tasks: allTasks.map((t) => {
        const sub = subByTask.get(t._id.toString())
        const p = programMap.get(t.programId.toString())
        return {
          id: t._id.toString(),
          title: t.title,
          description: t.description,
          rubric: t.rubric,
          order: t.order,
          points: t.points,
          deadline: t.deadline || null,
          aiGenerated: !!t.aiGenerated,
          programId: t.programId.toString(),
          programTitle: p?.title || "Program",
          programColor: p?.color || "indigo",
          submission: sub
            ? {
                id: sub._id.toString(),
                score: sub.score,
                verdict: sub.verdict,
                feedback: sub.feedback,
                strengths: sub.strengths,
                improvements: sub.improvements,
                plagiarismRisk: sub.plagiarismRisk ?? null,
                plagiarismNotes: sub.plagiarismNotes ?? null,
                fileUrl: sub.fileUrl ?? null,
                fileName: sub.fileName ?? null,
                submittedAt: sub.submittedAt,
              }
            : null,
        }
      }),
    })
  } catch (e) {
    console.log("[v0] tasks GET error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message, tasks: [] }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    const body = await req.json()
    const { tasks } = await getCollections()
    const _id = new ObjectId()
    let deadline: Date | null = null
    if (body.deadline) {
      const d = new Date(body.deadline)
      if (!isNaN(d.getTime())) deadline = d
    }
    await tasks.insertOne({
      _id,
      programId: new ObjectId(body.programId),
      title: body.title,
      description: body.description,
      rubric: body.rubric || "",
      order: Number(body.order) || 1,
      points: Number(body.points) || 100,
      deadline,
      aiGenerated: false,
      createdAt: new Date(),
    })
    return NextResponse.json({ id: _id.toString() })
  } catch (e) {
    console.log("[v0] tasks POST error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
