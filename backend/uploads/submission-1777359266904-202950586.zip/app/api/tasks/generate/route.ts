import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { generateTasksForProgram } from "@/lib/groq"
import { ObjectId } from "mongodb"

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { programId } = await req.json()
    if (!programId) return NextResponse.json({ error: "programId required" }, { status: 400 })

    const { programs, tasks, enrollments } = await getCollections()
    const pid = new ObjectId(programId)
    const program = await programs.findOne({ _id: pid })
    if (!program) return NextResponse.json({ error: "Program not found" }, { status: 404 })

    // Only run if program has no admin tasks
    const existing = await tasks.countDocuments({ programId: pid })
    if (existing > 0) {
      return NextResponse.json({ ok: true, generated: 0, message: "Tasks already exist." })
    }

    // Use enrollment duration if any, fallback program duration
    const enrollment = await enrollments.findOne({
      userId: new ObjectId(session.sub),
      programId: pid,
    })
    const durationWeeks = enrollment?.durationWeeks || parseDurationWeeks(program.duration) || 4

    let generated
    try {
      generated = await generateTasksForProgram({
        programTitle: program.title,
        programSummary: program.summary || "",
        skills: program.skills || [],
        level: program.level || "Beginner",
        durationWeeks,
      })
    } catch (e) {
      console.log("[v0] groq generate fallback:", (e as Error).message)
      generated = fallbackTasks(program.title, durationWeeks)
    }

    if (!generated.length) generated = fallbackTasks(program.title, durationWeeks)

    const enrollmentStart = enrollment?.enrolledAt ? new Date(enrollment.enrolledAt) : new Date()
    let cursor = new Date(enrollmentStart)
    const docs = generated.map((g, i) => {
      cursor = new Date(cursor.getTime() + g.estimatedDays * 24 * 60 * 60 * 1000)
      return {
        _id: new ObjectId(),
        programId: pid,
        title: g.title,
        description: g.description,
        rubric: g.rubric,
        order: g.order || i + 1,
        points: g.points || 100,
        estimatedDays: g.estimatedDays,
        deadline: new Date(cursor),
        aiGenerated: true,
        createdAt: new Date(),
      }
    })
    await tasks.insertMany(docs)
    return NextResponse.json({ ok: true, generated: docs.length })
  } catch (e) {
    console.log("[v0] generate tasks error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}

function parseDurationWeeks(s?: string): number {
  if (!s) return 0
  const m = String(s).match(/(\d+)/)
  return m ? Number(m[1]) : 0
}

function fallbackTasks(programTitle: string, weeks: number) {
  const count = Math.max(3, Math.min(6, weeks))
  return Array.from({ length: count }).map((_, i) => ({
    title: `Milestone ${i + 1} — ${programTitle}`,
    description: `Apply what you've learned in week ${i + 1}. Document your approach, results, and what you'd improve next.`,
    rubric: "Clarity, completeness, originality, communication.",
    order: i + 1,
    points: 100,
    estimatedDays: 5,
  }))
}
