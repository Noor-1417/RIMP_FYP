import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { getStripe, isStripeConfigured } from "@/lib/stripe"
import { ObjectId } from "mongodb"

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { sessionId, demo } = await req.json()
    if (!sessionId) return NextResponse.json({ error: "sessionId required" }, { status: 400 })

    const { payments, enrollments } = await getCollections()
    const payment = await payments.findOne({ sessionId })
    if (!payment) return NextResponse.json({ error: "Payment record not found" }, { status: 404 })

    let paid = false
    if (demo || payment.provider === "demo" || !isStripeConfigured()) {
      paid = true // demo mode auto-approves
    } else {
      const stripe = getStripe()
      const stripeSession = await stripe.checkout.sessions.retrieve(sessionId)
      paid = stripeSession.payment_status === "paid"
    }

    if (!paid) return NextResponse.json({ ok: false, status: "unpaid" })

    await payments.updateOne(
      { sessionId },
      { $set: { status: "paid", paidAt: new Date() } },
    )
    await enrollments.updateOne(
      { userId: payment.userId, programId: payment.programId },
      { $set: { status: "active", activatedAt: new Date() } },
    )
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.log("[v0] checkout confirm error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
