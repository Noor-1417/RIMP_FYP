import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { getStripe, isStripeConfigured, priceForDurationWeeks } from "@/lib/stripe"
import { ObjectId } from "mongodb"

export async function POST(req: Request) {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { programId, durationWeeks } = await req.json()
    if (!programId) return NextResponse.json({ error: "programId required" }, { status: 400 })

    const weeks = Math.max(1, Math.min(52, Number(durationWeeks) || 4))
    const priceCents = priceForDurationWeeks(weeks)
    if (priceCents === 0) return NextResponse.json({ error: "This duration is free." }, { status: 400 })

    const { programs, payments, enrollments } = await getCollections()
    const program = await programs.findOne({ _id: new ObjectId(programId) })
    if (!program) return NextResponse.json({ error: "Program not found" }, { status: 404 })

    const origin = req.headers.get("origin") || new URL(req.url).origin

    // Demo mode if Stripe is not configured
    if (!isStripeConfigured()) {
      const demoSessionId = `demo_${Date.now()}`
      await payments.insertOne({
        _id: new ObjectId(),
        userId: new ObjectId(session.sub),
        programId: new ObjectId(programId),
        durationWeeks: weeks,
        amount: priceCents,
        currency: "usd",
        status: "pending",
        provider: "demo",
        sessionId: demoSessionId,
        createdAt: new Date(),
      })
      return NextResponse.json({
        url: `/dashboard/checkout/success?session_id=${demoSessionId}&demo=1&program_id=${programId}`,
        demo: true,
      })
    }

    const stripe = getStripe()
    const checkout = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: "usd",
            unit_amount: priceCents,
            product_data: {
              name: `${program.title} — ${weeks} weeks`,
              description: program.summary?.slice(0, 220) || undefined,
            },
          },
        },
      ],
      success_url: `${origin}/dashboard/checkout/success?session_id={CHECKOUT_SESSION_ID}&program_id=${programId}`,
      cancel_url: `${origin}/dashboard/programs?canceled=1`,
      metadata: {
        userId: session.sub,
        programId,
        durationWeeks: String(weeks),
      },
    })

    await payments.insertOne({
      _id: new ObjectId(),
      userId: new ObjectId(session.sub),
      programId: new ObjectId(programId),
      durationWeeks: weeks,
      amount: priceCents,
      currency: "usd",
      status: "pending",
      provider: "stripe",
      sessionId: checkout.id,
      createdAt: new Date(),
    })

    // Mark enrollment pending
    await enrollments.updateOne(
      { userId: new ObjectId(session.sub), programId: new ObjectId(programId) },
      {
        $set: {
          status: "pending_payment",
          durationWeeks: weeks,
          priceCents,
          updatedAt: new Date(),
        },
        $setOnInsert: {
          _id: new ObjectId(),
          userId: new ObjectId(session.sub),
          programId: new ObjectId(programId),
          progress: 0,
          enrolledAt: new Date(),
        },
      },
      { upsert: true },
    )

    return NextResponse.json({ url: checkout.url })
  } catch (e) {
    console.log("[v0] checkout create error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
