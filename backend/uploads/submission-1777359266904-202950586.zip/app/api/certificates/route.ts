import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET() {
  try {
    const session = await getSession()
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    const { certificates } = await getCollections()
    const list = await certificates
      .find({ userId: new ObjectId(session.sub) })
      .sort({ issuedAt: -1 })
      .toArray()
    return NextResponse.json({
      certificates: list.map((c) => ({
        id: c._id.toString(),
        programTitle: c.programTitle,
        studentName: c.studentName,
        finalScore: c.finalScore,
        grade: c.grade || "Pass",
        verified: c.verified ?? true,
        credentialId: c.credentialId,
        issuedAt: c.issuedAt,
      })),
    })
  } catch (e) {
    console.log("[v0] certs error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message, certificates: [] }, { status: 500 })
  }
}
