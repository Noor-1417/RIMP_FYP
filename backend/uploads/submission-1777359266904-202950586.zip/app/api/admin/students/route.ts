import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"

export async function GET() {
  try {
    const session = await getSession()
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    const { users, enrollments, submissions, certificates } = await getCollections()
    const all = await users.find({ role: "student" }).sort({ createdAt: -1 }).toArray()
    const ids = all.map((u) => u._id)

    const [enrolls, subs, certs] = await Promise.all([
      enrollments.find({ userId: { $in: ids } }).toArray(),
      submissions.find({ userId: { $in: ids } }).toArray(),
      certificates.find({ userId: { $in: ids } }).toArray(),
    ])

    const enrollByUser = new Map<string, number>()
    enrolls.forEach((e) => enrollByUser.set(e.userId.toString(), (enrollByUser.get(e.userId.toString()) || 0) + 1))
    const subByUser = new Map<string, number>()
    subs.forEach((s) => subByUser.set(s.userId.toString(), (subByUser.get(s.userId.toString()) || 0) + 1))
    const certByUser = new Map<string, number>()
    certs.forEach((c) => certByUser.set(c.userId.toString(), (certByUser.get(c.userId.toString()) || 0) + 1))

    return NextResponse.json({
      students: all.map((u) => ({
        id: u._id.toString(),
        name: u.name,
        email: u.email,
        createdAt: u.createdAt,
        enrollments: enrollByUser.get(u._id.toString()) || 0,
        submissions: subByUser.get(u._id.toString()) || 0,
        certificates: certByUser.get(u._id.toString()) || 0,
      })),
    })
  } catch (e) {
    console.log("[v0] admin students error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message, students: [] }, { status: 500 })
  }
}
