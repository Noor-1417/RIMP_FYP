import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"

export async function GET() {
  try {
    const session = await getSession()
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    const { users, programs, enrollments, submissions, certificates, tasks } = await getCollections()
    const [studentCount, programCount, enrollmentCount, submissionCount, certCount, taskCount] = await Promise.all([
      users.countDocuments({ role: "student" }),
      programs.countDocuments(),
      enrollments.countDocuments(),
      submissions.countDocuments(),
      certificates.countDocuments(),
      tasks.countDocuments(),
    ])

    const recentSubs = await submissions.find({}).sort({ submittedAt: -1 }).limit(10).toArray()
    const userIds = recentSubs.map((s) => s.userId)
    const taskIds = recentSubs.map((s) => s.taskId)
    const [recentUsers, recentTasks] = await Promise.all([
      users.find({ _id: { $in: userIds } }).toArray(),
      tasks.find({ _id: { $in: taskIds } }).toArray(),
    ])
    const userMap = new Map(recentUsers.map((u) => [u._id.toString(), u]))
    const taskMap = new Map(recentTasks.map((t) => [t._id.toString(), t]))

    return NextResponse.json({
      stats: {
        students: studentCount,
        programs: programCount,
        enrollments: enrollmentCount,
        submissions: submissionCount,
        certificates: certCount,
        tasks: taskCount,
      },
      recentSubmissions: recentSubs.map((s) => ({
        id: s._id.toString(),
        studentName: userMap.get(s.userId.toString())?.name || "Student",
        taskTitle: taskMap.get(s.taskId.toString())?.title || "Task",
        score: s.score,
        verdict: s.verdict,
        submittedAt: s.submittedAt,
      })),
    })
  } catch (e) {
    console.log("[v0] admin stats error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
