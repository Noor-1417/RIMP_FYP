import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET(req: Request) {
  try {
    const session = await getSession()
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    const { searchParams } = new URL(req.url)
    const programId = searchParams.get("programId")
    const { tasks, programs } = await getCollections()
    const filter = programId ? { programId: new ObjectId(programId) } : {}
    const all = await tasks.find(filter).sort({ order: 1 }).toArray()
    const programIds = Array.from(new Set(all.map((t) => t.programId.toString()))).map((id) => new ObjectId(id))
    const allPrograms = await programs.find({ _id: { $in: programIds } }).toArray()
    const programMap = new Map(allPrograms.map((p) => [p._id.toString(), p]))

    return NextResponse.json({
      tasks: all.map((t) => ({
        id: t._id.toString(),
        title: t.title,
        description: t.description,
        rubric: t.rubric,
        order: t.order,
        points: t.points,
        programId: t.programId.toString(),
        programTitle: programMap.get(t.programId.toString())?.title || "Program",
      })),
    })
  } catch (e) {
    console.log("[v0] admin tasks error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message, tasks: [] }, { status: 500 })
  }
}
