import { NextResponse } from "next/server"
import { getCollections } from "@/lib/mongodb"
import { getSession } from "@/lib/auth"

export async function GET(req: Request) {
  try {
    const session = await getSession()
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    const { searchParams } = new URL(req.url)
    const flaggedOnly = searchParams.get("flagged") === "1"

    const { submissions, tasks, programs } = await getCollections()
    const filter: any = flaggedOnly ? { flagged: true } : {}
    const subs = await submissions.find(filter).sort({ submittedAt: -1 }).limit(200).toArray()
    const taskIds = Array.from(new Set(subs.map((s) => s.taskId.toString())))
    const programIds = Array.from(new Set(subs.map((s) => s.programId?.toString()).filter(Boolean) as string[]))

    const taskDocs = await tasks.find({ _id: { $in: taskIds.map((id) => new (require("mongodb").ObjectId)(id)) } }).toArray()
    const programDocs = await programs.find({ _id: { $in: programIds.map((id) => new (require("mongodb").ObjectId)(id)) } }).toArray()
    const taskMap = new Map(taskDocs.map((t) => [t._id.toString(), t]))
    const programMap = new Map(programDocs.map((p) => [p._id.toString(), p]))

    return NextResponse.json({
      submissions: subs.map((s) => ({
        id: s._id.toString(),
        studentName: s.studentName || "Student",
        studentEmail: s.studentEmail || "",
        taskTitle: taskMap.get(s.taskId.toString())?.title || "Task",
        programTitle: s.programId ? programMap.get(s.programId.toString())?.title || "Program" : "—",
        score: s.score,
        verdict: s.verdict,
        plagiarismRisk: s.plagiarismRisk ?? 0,
        plagiarismNotes: s.plagiarismNotes ?? "",
        feedback: s.feedback,
        strengths: s.strengths || [],
        improvements: s.improvements || [],
        fileUrl: s.fileUrl || null,
        fileName: s.fileName || null,
        flagged: !!s.flagged,
        submittedAt: s.submittedAt,
        submissionText: s.submissionText,
      })),
    })
  } catch (e) {
    console.log("[v0] admin submissions error:", (e as Error).message)
    return NextResponse.json({ error: (e as Error).message, submissions: [] }, { status: 500 })
  }
}
