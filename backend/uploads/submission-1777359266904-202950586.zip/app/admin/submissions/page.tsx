"use client"

import useSWR from "swr"
import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Download, ShieldAlert, Sparkles, FileText, Filter } from "lucide-react"
import { cn } from "@/lib/utils"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function AdminSubmissionsPage() {
  const [flagged, setFlagged] = useState(false)
  const { data } = useSWR(`/api/admin/submissions${flagged ? "?flagged=1" : ""}`, fetcher)
  const list: any[] = data?.submissions || []

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">AI Reports</h1>
          <p className="mt-1 text-muted-foreground">
            Every submission, AI score, and plagiarism risk. Filter to flagged-only when something looks off.
          </p>
        </div>
        <Button
          variant={flagged ? "default" : "outline"}
          onClick={() => setFlagged((f) => !f)}
          className={cn(!flagged && "bg-transparent")}
        >
          <Filter className="h-4 w-4" /> {flagged ? "Showing flagged only" : "All submissions"}
        </Button>
      </div>

      {!data ? (
        <div className="text-muted-foreground">Loading reports...</div>
      ) : list.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <Sparkles className="h-10 w-10 mx-auto text-muted-foreground" />
          <div className="mt-3 font-display font-semibold">No submissions yet</div>
          <p className="mt-1 text-sm text-muted-foreground">
            When students submit work, AI evaluations and plagiarism reports appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {list.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.02 }}
              className={cn(
                "rounded-2xl border bg-card p-5",
                s.flagged ? "border-destructive/30" : "border-border",
              )}
            >
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="min-w-0">
                  <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                    {s.programTitle} · {new Date(s.submittedAt).toLocaleString()}
                  </div>
                  <h3 className="font-display font-bold mt-0.5">{s.taskTitle}</h3>
                  <div className="mt-1 text-sm">
                    <span className="font-semibold">{s.studentName}</span>
                    <span className="text-muted-foreground"> · {s.studentEmail}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "text-xs font-mono font-bold px-2 py-1 rounded-full",
                      s.verdict === "passed"
                        ? "bg-accent/15 text-accent-foreground"
                        : s.verdict === "needs_revision"
                          ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                          : "bg-destructive/10 text-destructive",
                    )}
                  >
                    {s.score}/100 · {s.verdict.replace("_", " ")}
                  </span>
                  <span
                    className={cn(
                      "text-xs font-semibold inline-flex items-center gap-1 px-2 py-1 rounded-full",
                      s.flagged
                        ? "bg-destructive/10 text-destructive"
                        : s.plagiarismRisk >= 40
                          ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                          : "bg-muted text-muted-foreground",
                    )}
                  >
                    <ShieldAlert className="h-3 w-3" />
                    Plagiarism {s.plagiarismRisk}/100
                  </span>
                </div>
              </div>

              <p className="mt-3 text-sm leading-relaxed">{s.feedback}</p>

              <div className="mt-3 grid gap-3 md:grid-cols-2 text-xs">
                {s.strengths?.length > 0 && (
                  <div className="rounded-lg bg-muted/40 p-3">
                    <div className="font-semibold uppercase tracking-wider text-muted-foreground">Strengths</div>
                    <ul className="mt-1 space-y-0.5">
                      {s.strengths.map((x: string, i: number) => (
                        <li key={i}>• {x}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {s.improvements?.length > 0 && (
                  <div className="rounded-lg bg-muted/40 p-3">
                    <div className="font-semibold uppercase tracking-wider text-muted-foreground">Improvements</div>
                    <ul className="mt-1 space-y-0.5">
                      {s.improvements.map((x: string, i: number) => (
                        <li key={i}>• {x}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {s.plagiarismNotes && (
                <div className="mt-3 text-xs text-muted-foreground italic">
                  Plagiarism note: {s.plagiarismNotes}
                </div>
              )}

              {s.fileUrl && (
                <div className="mt-3">
                  <Button asChild size="sm" variant="outline" className="bg-transparent">
                    <a
                      href={s.fileUrl}
                      download={s.fileName || true}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {s.fileUrl.startsWith("data:") ? <Download className="h-3.5 w-3.5" /> : <FileText className="h-3.5 w-3.5" />}
                      {s.fileName || "Download submission"}
                    </a>
                  </Button>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
