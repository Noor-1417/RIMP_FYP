"use client"

import useSWR from "swr"
import { Suspense, useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Plus, Clock } from "lucide-react"
import { toast } from "sonner"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

function AdminProgramsInner() {
  const router = useRouter()
  const params = useSearchParams()
  const { data, mutate } = useSWR("/api/programs", fetcher)
  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    title: "",
    summary: "",
    duration: "4 weeks",
    level: "Beginner",
    category: "Engineering",
    skills: "",
  })

  useEffect(() => {
    if (params.get("new")) setOpen(true)
  }, [params])

  async function save() {
    if (!form.title || !form.summary) {
      toast.error("Title and summary are required.")
      return
    }
    setSaving(true)
    try {
      const res = await fetch("/api/programs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, skills: form.skills.split(",").map((s) => s.trim()).filter(Boolean) }),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Failed")
      toast.success("Program created")
      setOpen(false)
      setForm({ title: "", summary: "", duration: "4 weeks", level: "Beginner", category: "Engineering", skills: "" })
      mutate()
      router.replace("/admin/programs")
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  const programs: any[] = data?.programs || []

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Programs</h1>
          <p className="mt-1 text-muted-foreground">Create and manage your internship programs.</p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> New program
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {programs.map((p, i) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            className="rounded-2xl border border-border bg-card p-6"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">{p.category}</span>
              <span className="text-xs font-semibold rounded-full bg-secondary px-2 py-0.5">{p.level}</span>
            </div>
            <h3 className="font-display font-bold text-lg leading-tight text-balance">{p.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground line-clamp-2 leading-relaxed">{p.summary}</p>
            <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" /> {p.duration}
              </span>
              <span>{p.taskCount} tasks</span>
            </div>
          </motion.div>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create a program</DialogTitle>
            <DialogDescription>Define the basics. You can add tasks afterwards.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Frontend Engineering with React"
              />
            </div>
            <div>
              <Label htmlFor="summary">Summary</Label>
              <Textarea
                id="summary"
                rows={3}
                value={form.summary}
                onChange={(e) => setForm({ ...form, summary: e.target.value })}
                placeholder="Build modern, accessible web apps using React and Tailwind."
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label htmlFor="duration">Duration</Label>
                <Input id="duration" value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="level">Level</Label>
                <Input id="level" value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Input id="category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
              </div>
            </div>
            <div>
              <Label htmlFor="skills">Skills (comma-separated)</Label>
              <Input
                id="skills"
                value={form.skills}
                onChange={(e) => setForm({ ...form, skills: e.target.value })}
                placeholder="React, TypeScript, Tailwind"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving ? "Saving..." : "Create program"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function AdminProgramsPage() {
  return (
    <Suspense>
      <AdminProgramsInner />
    </Suspense>
  )
}
