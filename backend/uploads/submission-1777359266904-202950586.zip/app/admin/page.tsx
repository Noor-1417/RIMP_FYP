"use client"

import useSWR from "swr"
import Link from "next/link"
import { motion } from "framer-motion"
import { Users, BookOpen, ClipboardCheck, Award, Plus, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function AdminDashboard() {
  const { data } = useSWR("/api/admin/stats", fetcher)
  const stats = data?.stats || {}
  const recent = data?.recentSubmissions || []

  const cards = [
    { label: "Students", value: stats.students || 0, icon: Users, accent: "text-primary bg-primary/10" },
    { label: "Programs", value: stats.programs || 0, icon: BookOpen, accent: "text-accent-foreground bg-accent/15" },
    { label: "Submissions", value: stats.submissions || 0, icon: ClipboardCheck, accent: "text-primary bg-primary/10" },
    { label: "Certificates", value: stats.certificates || 0, icon: Award, accent: "text-amber-700 bg-amber-100 dark:bg-amber-500/15 dark:text-amber-300" },
  ]

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Admin overview</h1>
          <p className="mt-1 text-muted-foreground">Manage programs, tasks, and review student progress.</p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" className="bg-transparent">
            <Link href="/admin/tasks?new=1">
              <Plus className="h-4 w-4" /> New task
            </Link>
          </Button>
          <Button asChild>
            <Link href="/admin/programs?new=1">
              <Plus className="h-4 w-4" /> New program
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-2xl border border-border bg-card p-5"
          >
            <div className="flex items-center justify-between">
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${s.accent}`}>
                <s.icon className="h-5 w-5" />
              </div>
              <div className="text-3xl font-display font-bold tabular-nums">{s.value}</div>
            </div>
            <div className="mt-3 text-sm text-muted-foreground">{s.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-xl">Recent submissions</h2>
        </div>
        {recent.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            No submissions yet. Once students submit work, AI-reviewed entries will appear here.
          </div>
        ) : (
          <div className="overflow-x-auto -mx-2">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="text-left px-2 py-2 font-medium">Student</th>
                  <th className="text-left px-2 py-2 font-medium">Task</th>
                  <th className="text-left px-2 py-2 font-medium">Score</th>
                  <th className="text-left px-2 py-2 font-medium">Verdict</th>
                  <th className="text-left px-2 py-2 font-medium">When</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((r: any) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-2 py-3 font-medium">{r.studentName}</td>
                    <td className="px-2 py-3 text-muted-foreground">{r.taskTitle}</td>
                    <td className="px-2 py-3 font-mono font-bold">{r.score}/100</td>
                    <td className="px-2 py-3">
                      <span
                        className={cn(
                          "text-xs font-semibold px-2 py-0.5 rounded-full",
                          r.verdict === "passed"
                            ? "bg-accent/15 text-accent-foreground"
                            : r.verdict === "needs_revision"
                              ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
                              : "bg-destructive/10 text-destructive",
                        )}
                      >
                        {r.verdict.replace("_", " ")}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-xs text-muted-foreground">
                      {new Date(r.submittedAt).toLocaleString(undefined, {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Link
          href="/admin/programs"
          className="group flex items-center justify-between rounded-2xl border border-border bg-card p-6 hover:border-primary/30 transition-colors"
        >
          <div>
            <div className="flex items-center gap-2 text-primary">
              <BookOpen className="h-5 w-5" />
              <span className="font-display font-bold">Programs</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Create programs and skills.</p>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-1" />
        </Link>
        <Link
          href="/admin/tasks"
          className="group flex items-center justify-between rounded-2xl border border-border bg-card p-6 hover:border-primary/30 transition-colors"
        >
          <div>
            <div className="flex items-center gap-2 text-accent-foreground">
              <ClipboardCheck className="h-5 w-5" />
              <span className="font-display font-bold">Tasks</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Tasks, rubrics, deadlines.</p>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-1" />
        </Link>
        <Link
          href="/admin/submissions"
          className="group flex items-center justify-between rounded-2xl border border-border bg-card p-6 hover:border-primary/30 transition-colors"
        >
          <div>
            <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
              <Award className="h-5 w-5" />
              <span className="font-display font-bold">AI Reports</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Plagiarism + scores per submission.</p>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
    </div>
  )
}
