"use client"

import useSWR from "swr"
import { Suspense, useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Plus } from "lucide-react"
import { toast } from "sonner"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

function AdminTasksInner() {
  const router = useRouter()
  const params = useSearchParams()
  const { data: programData } = useSWR("/api/programs", fetcher)
  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [selectedProgram, setSelectedProgram] = useState<string>("")
  const [form, setForm] = useState({
    programId: "",
    title: "",
    description: "",
    rubric: "",
    order: "1",
    points: "100",
    deadline: "",
  })

  useEffect(() => {
    if (params.get("new")) setOpen(true)
  }, [params])

  const programs: any[] = programData?.programs || []

  // Fetch tasks for selected program (or all)
  const tasksUrl = selectedProgram ? `/api/admin/tasks?programId=${selectedProgram}` : "/api/admin/tasks"
  const { data: taskData, mutate } = useSWR(programs.length ? tasksUrl : null, fetcher)
  const tasks: any[] = taskData?.tasks || []

  async function save() {
    if (!form.programId || !form.title || !form.description) {
      toast.error("Program, title, and description are required.")
      return
    }
    setSaving(true)
    try {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Failed")
      toast.success("Task created")
      setOpen(false)
      setForm({ programId: "", title: "", description: "", rubric: "", order: "1", points: "100", deadline: "" })
      mutate()
      router.replace("/admin/tasks")
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Tasks</h1>
          <p className="mt-1 text-muted-foreground">Create tasks and rubrics for AI evaluation.</p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> New task
        </Button>
      </div>

      <div className="flex items-center gap-3">
        <Label htmlFor="filter" className="text-sm">Filter by program:</Label>
        <Select value={selectedProgram || "all"} onValueChange={(v) => setSelectedProgram(v === "all" ? "" : v)}>
          <SelectTrigger id="filter" className="w-72">
            <SelectValue placeholder="All programs" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All programs</SelectItem>
            {programs.map((p) => (
              <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        {tasks.map((t, i) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.03 }}
            className="rounded-2xl border border-border bg-card p-5"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  {t.programTitle} · #{t.order}
                </div>
                <h3 className="font-display font-bold mt-0.5">{t.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{t.description}</p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xs text-muted-foreground">Points</div>
                <div className="font-mono font-bold">{t.points}</div>
              </div>
            </div>
          </motion.div>
        ))}
        {taskData && tasks.length === 0 && (
          <div className="rounded-2xl border border-dashed border-border p-10 text-center">
            <div className="font-display font-semibold">No tasks yet</div>
            <p className="mt-1 text-sm text-muted-foreground">Create your first task to get started.</p>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create a task</DialogTitle>
            <DialogDescription>The rubric guides AI evaluation of student submissions.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Program</Label>
              <Select value={form.programId} onValueChange={(v) => setForm({ ...form, programId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a program" />
                </SelectTrigger>
                <SelectContent>
                  {programs.map((p) => (
                    <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="t-title">Title</Label>
              <Input
                id="t-title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Build an Accessible Landing Page"
              />
            </div>
            <div>
              <Label htmlFor="t-desc">Description</Label>
              <Textarea
                id="t-desc"
                rows={4}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Describe what students should build..."
              />
            </div>
            <div>
              <Label htmlFor="t-rubric">Rubric</Label>
              <Textarea
                id="t-rubric"
                rows={2}
                value={form.rubric}
                onChange={(e) => setForm({ ...form, rubric: e.target.value })}
                placeholder="Semantic HTML, accessibility, code quality..."
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label htmlFor="t-order">Order</Label>
                <Input id="t-order" type="number" value={form.order} onChange={(e) => setForm({ ...form, order: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="t-points">Points</Label>
                <Input id="t-points" type="number" value={form.points} onChange={(e) => setForm({ ...form, points: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="t-deadline">Deadline</Label>
                <Input
                  id="t-deadline"
                  type="date"
                  value={form.deadline}
                  onChange={(e) => setForm({ ...form, deadline: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? "Saving..." : "Create task"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function AdminTasksPage() {
  return (
    <Suspense>
      <AdminTasksInner />
    </Suspense>
  )
}
