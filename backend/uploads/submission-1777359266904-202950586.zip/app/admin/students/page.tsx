"use client"

import useSWR from "swr"
import { motion } from "framer-motion"
import { Users } from "lucide-react"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function AdminStudentsPage() {
  const { data } = useSWR("/api/admin/students", fetcher)
  const students: any[] = data?.students || []

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Students</h1>
        <p className="mt-1 text-muted-foreground">Track every learner&apos;s progress across programs.</p>
      </div>

      {students.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center">
          <Users className="h-10 w-10 mx-auto text-muted-foreground" />
          <div className="mt-3 font-display font-semibold">No students yet</div>
          <p className="mt-1 text-sm text-muted-foreground">When students sign up, they&apos;ll appear here.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">Email</th>
                  <th className="text-left px-4 py-3 font-medium">Enrolled</th>
                  <th className="text-left px-4 py-3 font-medium">Submissions</th>
                  <th className="text-left px-4 py-3 font-medium">Certificates</th>
                  <th className="text-left px-4 py-3 font-medium">Joined</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s, i) => (
                  <motion.tr
                    key={s.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.02 }}
                    className="border-t border-border"
                  >
                    <td className="px-4 py-3 font-medium">{s.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{s.email}</td>
                    <td className="px-4 py-3 font-mono">{s.enrollments}</td>
                    <td className="px-4 py-3 font-mono">{s.submissions}</td>
                    <td className="px-4 py-3 font-mono">{s.certificates}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {new Date(s.createdAt).toLocaleDateString()}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
